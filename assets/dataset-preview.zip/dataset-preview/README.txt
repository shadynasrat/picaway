Anonymous dataset preview

This preview contains the manuscript dataset overview figure and aggregate drawing/editing benchmark tables as CSV. It does not contain individual input images, masks, saved trajectories, or the full reproducibility dataset. Full dataset access is being prepared separately.

Scope: 416 drawing images; 140 evaluated image-edit examples; six methods; five tool widths.
