# Footprint-aware planning

Anonymous review code for **Footprint-Aware Planning for Robotic Drawing and Physical Inpainting**.

## Install

Python 3.11 or newer; tested with Python 3.13 on Linux.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-lock.txt
python -m pip install -e .
```

## Draw

```bash
python -m footprint draw examples/drawing.png --width-mm 3 --canvas-mm 64 48 --out outputs/drawing
```

## Erase and redraw

```bash
python -m footprint edit --parent examples/parent.png --mask examples/mask.png --updated examples/updated.png --width-mm 3 --canvas-mm 64 48 --out outputs/edit
```

White mask pixels select the edit region. Outputs contain full-precision millimeter paths and previews. Use a new output directory. The default canvas is 700 × 350 mm; the included synthetic examples use 64 × 48 mm. Coordinates start at the top left; x increases right and y down. Protected eraser clipping retains ink outside the selected mask. Coverage is sampled coverage.

## Benchmarks

Use `--method proposed`, `legacy_picaso`, `centerline_tracing`, `contour_tracing`, `coverage_planning`, or `naive_centerline_coverage`. PICaSo is a comparison baseline described in the manuscript.

```bash
python -m pip install -r requirements-benchmark-lock.txt
python -m pip install -e ".[benchmark,download]"
python -m footprint reproduce --data data/paper-v1 --out outputs/tables
python -m footprint rescore --data data/paper-v1 --task drawing --id drawing-0003 --method proposed --width-mm 2 --out outputs/rescore
```

The anonymous dataset is being prepared separately. These benchmark commands require that dataset with `proposed` as the proposed-method identifier. Table reproduction aggregates saved metrics; rescoring evaluates saved trajectories without replanning. No private download location or credentials are embedded. The optional HF downloader requires an explicit repository and immutable revision.

## Verify

```bash
python -m unittest discover -s tests -v
```

The review snapshot changes package names and identifying documentation, not planner geometry. `docs/source-manifest.json` records review-copy checksums. Original code and dependency license notices are included. The source archive contains no Git history, website, video, dataset, or compiled files.
