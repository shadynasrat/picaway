# Paper dataset format

Version `paper-v1` preserves the corrected submitted 416-target drawing membership and matched 140-example editing selection. Archives share one extraction root. Start with the results archive; add input and trajectory bundles for each task as needed.

`manifest.json` records every payload file's SHA-256 and byte size. `cells.jsonl` maps `(task, id, method, width_mm)` to trajectory files. Public IDs are stable within this version; private session IDs and account metadata are excluded.

Drawing input records link original images, evaluated binary targets, prompts, generator provenance, candidate selection, settings, and canvas geometry. Editing input records link parent/mask/update images, instructions, public conversation groups, and matching parent example IDs when the parent belongs to the evaluated subset. The included parent image is authoritative; multiple IDs can share image content.

Drawing `.json.gz` records contain `paths` in **pixel units**, with `scale_mm_per_pixel` `[700/1024, 350/512]`. Editing records contain `parent`, `erase`, and `draw` in **millimeters**. Both include method, tool diameter, public ID, canvas size, raster size, and axis conventions. Never apply the drawing scale to editing paths. The coordinate values are preserved without rounding. Empty path lists represent no contact; do not connect separate strokes with ink.

Drawing target masks are grayscale <128. Editing parent/update ink is grayscale <180, and edit masks are grayscale ≥128. Pixel centers are integer coordinates and cell boundaries are ±0.5 pixel; the physical extent is divided by pixel count. The editing evaluator starts all six methods from the same saved parent footprint per example/width, rather than using the raw parent raster as simulated ink.

The four corrected drawing records carry author-confirmed Qwen provenance and the historical `runwayML` alias separately; their exact checkpoint is unverified. No record is removed to turn the benchmark into a 412-image set. Editing excludes two collected examples with polygon-overlay failures uniformly across methods and widths; seven included examples are addition-only. Generation settings reflect recorded metadata, not a guarantee that an unavailable exact generator revision can be replayed.

Per-cell result files support table aggregation. `rescore` independently recomputes metrics from input images and saved paths, using the preserved numerical evaluators. Full-collection regeneration and physical execution are not prerequisites. Reference paths are algorithm outputs, not ground truth. Large WKB caches are reconstructed during geometric rescoring and are not part of the required download.
