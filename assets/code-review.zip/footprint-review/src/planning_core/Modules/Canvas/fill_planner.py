"""Fixed-marker fill planning for the digital waypoint extraction pipeline.

This first planner deliberately accepts a binary region mask rather than an
image.  The boundary is therefore explicit ground truth, and the experiment
can measure the planner independently from segmentation or semantic
interpretation.  It uses clipped, alternating scanlines and a marker-footprint
erosion; no robot execution is involved.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Sequence

import cv2
import numpy as np

from planning_core.Modules.Canvas.drawing_contract import DrawingContract


Point = tuple[float, float]
Stroke = tuple[Point, ...]


@dataclass
class FillPlan:
    """A deterministic digital fill plan and its rendered marker footprint."""

    strokes: list[Stroke]
    safe_centerline_mask: np.ndarray
    coverage_mask: np.ndarray
    pass_count: np.ndarray
    metrics: dict[str, float | int | str]

    def to_dict(self) -> dict[str, object]:
        return {
            "primitive": "fill",
            "strokes": [[list(point) for point in stroke] for stroke in self.strokes],
            "metrics": dict(self.metrics),
        }


def _as_region_mask(region_mask: np.ndarray, contract: DrawingContract) -> np.ndarray:
    mask = np.asarray(region_mask, dtype=bool)
    if mask.shape != contract.canvas_shape:
        raise ValueError(
            f"region_mask has shape {mask.shape}; expected {contract.canvas_shape}"
        )
    return mask


def _erode_for_marker(
    region_mask: np.ndarray,
    contract: DrawingContract,
    margin_mm: float,
) -> np.ndarray:
    radius_x = max(0, int(math.ceil(margin_mm / contract.millimetres_per_pixel_x)))
    radius_y = max(0, int(math.ceil(margin_mm / contract.millimetres_per_pixel_y)))
    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (2 * radius_x + 1, 2 * radius_y + 1),
    )
    return cv2.erode(region_mask.astype(np.uint8), kernel) > 0


def _runs(row: np.ndarray) -> list[tuple[int, int]]:
    """Return inclusive foreground runs from one binary row."""

    active = np.flatnonzero(row)
    if active.size == 0:
        return []
    breaks = np.flatnonzero(np.diff(active) > 1)
    starts = np.concatenate(([0], breaks + 1))
    ends = np.concatenate((breaks, [active.size - 1]))
    return [(int(active[start]), int(active[end])) for start, end in zip(starts, ends)]


def _line_mask(
    shape: tuple[int, int],
    stroke: Stroke,
    marker_width_pixels: tuple[float, float],
) -> np.ndarray:
    canvas = np.zeros(shape, dtype=np.uint8)
    if not stroke:
        return canvas.astype(bool)
    points = np.asarray(stroke, dtype=float)
    scaled = np.rint(points).astype(int)
    diameter = max(1, int(round(max(marker_width_pixels))))
    radius_x = max(1, int(round(marker_width_pixels[0] / 2.0)))
    radius_y = max(1, int(round(marker_width_pixels[1] / 2.0)))

    for start, end in zip(scaled[:-1], scaled[1:]):
        cv2.line(
            canvas,
            tuple(start),
            tuple(end),
            1,
            thickness=diameter,
            lineType=cv2.LINE_8,
        )
    for point in scaled:
        cv2.ellipse(
            canvas,
            tuple(point),
            (radius_x, radius_y),
            0.0,
            0.0,
            360.0,
            1,
            thickness=-1,
            lineType=cv2.LINE_8,
        )
    return canvas.astype(bool)


def render_marker_strokes(
    strokes: Sequence[Stroke],
    shape: tuple[int, int],
    marker_width_pixels: tuple[float, float],
) -> tuple[np.ndarray, np.ndarray]:
    """Render the marker footprint and per-pass overlap counts."""

    coverage = np.zeros(shape, dtype=bool)
    pass_count = np.zeros(shape, dtype=np.uint16)
    for stroke in strokes:
        stroke_mask = _line_mask(shape, stroke, marker_width_pixels)
        coverage |= stroke_mask
        pass_count += stroke_mask.astype(np.uint16)
    return coverage, pass_count


def _to_original_coordinates(
    point: Point,
    scan_angle_degrees: int,
) -> Point:
    x, y = point
    if scan_angle_degrees in (90, 270):
        return (y, x)
    return (x, y)


def _stroke_length_mm(stroke: Stroke, contract: DrawingContract) -> float:
    if len(stroke) < 2:
        return 0.0
    points_mm = contract.pixel_to_mm(np.asarray(stroke, dtype=float))
    return float(np.linalg.norm(np.diff(points_mm, axis=0), axis=1).sum())


def plan_fill_region(
    region_mask: np.ndarray,
    contract: DrawingContract,
    *,
    spacing_mm: float = 4.0,
    margin_mm: float | None = None,
    scan_angle_degrees: int = 0,
) -> FillPlan:
    """Create clipped hatch strokes for a binary region.

    ``margin_mm`` defaults to the marker radius.  Only axis-aligned scan
    directions are enabled in this characterization slice; accepting arbitrary
    angles before the raster-to-vector contract is settled would make the
    coverage results harder to interpret.
    """

    region = _as_region_mask(region_mask, contract)
    if spacing_mm <= 0:
        raise ValueError("spacing_mm must be positive")
    if margin_mm is None:
        margin_mm = contract.marker_radius_mm
    if margin_mm < 0:
        raise ValueError("margin_mm must be non-negative")
    if scan_angle_degrees not in (0, 90, 180, 270):
        raise ValueError("scan_angle_degrees must be one of 0, 90, 180, or 270")

    safe = _erode_for_marker(region, contract, margin_mm)
    work = safe.T if scan_angle_degrees in (90, 270) else safe
    spacing_pixels = max(
        1,
        int(round(
            spacing_mm
            / (
                contract.millimetres_per_pixel_x
                if scan_angle_degrees in (90, 270)
                else contract.millimetres_per_pixel_y
            )
        )),
    )

    rows = np.flatnonzero(work.any(axis=1))
    work_strokes: list[Stroke] = []
    if rows.size:
        scan_rows = list(range(int(rows[0]), int(rows[-1]) + 1, spacing_pixels))
        if scan_rows[-1] != int(rows[-1]):
            scan_rows.append(int(rows[-1]))
        for line_index, y in enumerate(scan_rows):
            row_runs = _runs(work[y])
            if line_index % 2:
                row_runs = list(reversed(row_runs))
            for start, end in row_runs:
                if line_index % 2:
                    points: Stroke = ((float(end), float(y)), (float(start), float(y)))
                else:
                    points = ((float(start), float(y)), (float(end), float(y)))
                work_strokes.append(points)

    strokes = [
        tuple(_to_original_coordinates(point, scan_angle_degrees) for point in stroke)
        for stroke in work_strokes
    ]
    coverage, pass_count = render_marker_strokes(
        strokes,
        contract.canvas_shape,
        contract.marker_width_pixels,
    )

    region_area = int(region.sum())
    covered_area = int(np.logical_and(region, coverage).sum())
    outside_area = int(np.logical_and(~region, coverage).sum())
    rendered_area = int(coverage.sum())
    overlap_area = int(np.maximum(pass_count.astype(np.int32) - 1, 0).sum())
    denominator = max(1, region_area)
    metrics: dict[str, float | int | str] = {
        "primitive": "fill",
        "spacing_mm": float(spacing_mm),
        "margin_mm": float(margin_mm),
        "scan_angle_degrees": int(scan_angle_degrees),
        "marker_width_mm": float(contract.marker_width_mm),
        "stroke_count": len(strokes),
        "pass_count": len(strokes),
        "total_draw_length_mm": _total_draw_length_mm(strokes, contract),
        "region_area_pixels": region_area,
        "covered_area_pixels": covered_area,
        "outside_area_pixels": outside_area,
        "overlap_area_pixels": overlap_area,
        "coverage_ratio": covered_area / denominator,
        "outside_region_ratio": outside_area / denominator,
        "overlap_ratio": overlap_area / max(1, rendered_area),
    }
    return FillPlan(strokes, safe, coverage, pass_count, metrics)


def _total_draw_length_mm(strokes: Sequence[Stroke], contract: DrawingContract) -> float:
    return float(sum(_stroke_length_mm(stroke, contract) for stroke in strokes))
