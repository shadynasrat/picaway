"""Footprint 1.0.0: frozen coverage-first marker path planner.

The underlying module names are retained for compatibility. The release tag
footprint-v1.0.0 pins their implementation; new behavior requires a new release.
"""
from .hybrid_coverage import (
    VERSION,
    HybridPolicy as FootprintPolicy,
    HybridResult as FootprintResult,
    plan_hybrid_coverage as plan_footprint,
)

__all__ = ["VERSION", "FootprintPolicy", "FootprintResult", "plan_footprint"]
