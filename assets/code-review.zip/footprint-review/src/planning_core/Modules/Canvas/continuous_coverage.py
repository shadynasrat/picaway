"""Experimental, footprint-checked connected contour coverage.

This module is deliberately separate from the deployed V5 planner. Certificates
refer to pixel-centre samples of a circular marker swept along the exported
polylines, not continuous image regions or calibrated robot execution. The
feasibility search uses integer centres and their eight neighbouring moves.
"""

from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter

import cv2
import networkx as nx
import numpy as np
from scipy.ndimage import distance_transform_edt
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components, dijkstra
from scipy.spatial import cKDTree

from .drawing_contract import DrawingContract


VERSION = "experimental-connected-contours-v1"
MODEL = "pixel-centre circular-marker sweep; integer-centre 8-neighbour search"


@dataclass(frozen=True)
class ContinuousCoveragePolicy:
    stepover_fraction: float = 0.75
    stitch_contours: bool = True
    smooth: bool = True
    corner_fraction: float = 0.25
    minimum_curve_segment_mm: float = 0.15

    def __post_init__(self):
        if not 0 < self.stepover_fraction <= 1:
            raise ValueError("stepover_fraction must be in (0, 1]")
        if not 0 < self.corner_fraction <= 0.45:
            raise ValueError("corner_fraction must be in (0, 0.45]")
        if not np.isfinite(self.minimum_curve_segment_mm) or self.minimum_curve_segment_mm <= 0:
            raise ValueError("minimum_curve_segment_mm must be finite and positive")


@dataclass
class ContinuousCoverageResult:
    status: str
    paths: tuple[np.ndarray, ...]
    coverage_mask: np.ndarray
    unreachable_mask: np.ndarray
    metrics: dict
    contract: DrawingContract

    def to_dict(self):
        return {
            "pipeline_version": VERSION,
            "experimental": True,
            "certificate_model": MODEL,
            "status": self.status,
            "contract": self.contract.to_dict(),
            "metrics": self.metrics,
            "paths": [
                {"path_id": i, "points": p.tolist(), "points_mm": self.contract.pixel_to_mm(p).tolist()}
                for i, p in enumerate(self.paths)
            ],
        }


class _Footprint:
    def __init__(self, contract):
        self.shape = contract.canvas_shape
        self.scale = np.array([contract.millimetres_per_pixel_x, contract.millimetres_per_pixel_y])
        self.radius = contract.marker_radius_mm

    def pixels(self, a, b):
        """Exact capsule membership at pixel centres; return flat ids + exterior flag."""
        a, b = np.asarray(a, float), np.asarray(b, float)
        lo = np.floor(np.minimum(a, b) - self.radius / self.scale).astype(int)
        hi = np.ceil(np.maximum(a, b) + self.radius / self.scale).astype(int)
        yy, xx = np.mgrid[lo[1]:hi[1] + 1, lo[0]:hi[0] + 1]
        delta = (b - a) * self.scale
        px, py = (xx - a[0]) * self.scale[0], (yy - a[1]) * self.scale[1]
        norm = float(delta @ delta)
        t = np.clip((px * delta[0] + py * delta[1]) / norm, 0, 1) if norm else 0.0
        inside = (px - t * delta[0]) ** 2 + (py - t * delta[1]) ** 2 <= self.radius ** 2 + 1e-10
        in_canvas = (xx >= 0) & (xx < self.shape[1]) & (yy >= 0) & (yy < self.shape[0])
        valid = inside & in_canvas
        return (yy[valid] * self.shape[1] + xx[valid]).astype(np.int64), bool(np.any(inside & ~in_canvas))

    def safe(self, a, b, allowed):
        ids, exterior = self.pixels(a, b)
        return not exterior and bool(np.all(allowed.ravel()[ids]))


def render_swept_paths(paths, contract):
    """Independent of V5's rounded-width OpenCV renderer; counts each segment."""
    footprint = _Footprint(contract)
    counts = np.zeros(contract.canvas_shape, np.int32)
    for path in paths:
        path = np.asarray(path, float)
        if len(path) == 1:
            ids, _ = footprint.pixels(path[0], path[0])
            counts.ravel()[ids] += 1
        for a, b in zip(path[:-1], path[1:]):
            ids, _ = footprint.pixels(a, b)
            counts.ravel()[ids] += 1
    return counts > 0


def _primitives(target, footprint):
    """All safe point and unit-segment placements, including intermediate sweep."""
    pad = np.ceil(footprint.radius / footprint.scale).astype(int) + 1
    yy, xx = np.mgrid[-pad[1]:pad[1] + 1, -pad[0]:pad[0] + 1]
    px, py = xx * footprint.scale[0], yy * footprint.scale[1]
    primitives = []
    reachable = np.zeros_like(target)
    for dx, dy in ((0, 0), (1, 0), (0, 1), (1, 1), (1, -1)):
        delta = np.array([dx, dy]) * footprint.scale
        norm = float(delta @ delta)
        t = np.clip((px * delta[0] + py * delta[1]) / norm, 0, 1) if norm else 0.0
        kernel = ((px - t * delta[0]) ** 2 + (py - t * delta[1]) ** 2 <= footprint.radius ** 2 + 1e-10).astype(np.uint8)
        legal = cv2.erode(target.astype(np.uint8), kernel, borderType=cv2.BORDER_CONSTANT, borderValue=0).astype(bool)
        # The destination must be an in-canvas centre even for subpixel tools.
        dest_valid = np.zeros_like(target)
        ys, xs = np.nonzero(legal)
        valid = (ys + dy >= 0) & (ys + dy < target.shape[0]) & (xs + dx < target.shape[1])
        dest_valid[ys[valid], xs[valid]] = True
        legal &= dest_valid
        reachable |= cv2.dilate(legal.astype(np.uint8), kernel[::-1, ::-1], borderType=cv2.BORDER_CONSTANT, borderValue=0).astype(bool)
        offsets = np.column_stack((xx[kernel > 0], yy[kernel > 0]))
        primitives.append((dx, dy, legal, offsets))
    return primitives, reachable


def _safe_graph(primitives, footprint):
    ys, xs = np.nonzero(primitives[0][2])
    coords = np.column_stack((xs, ys))
    ids = np.full(footprint.shape, -1, np.int32)
    ids[ys, xs] = np.arange(len(xs))
    us, vs, weights = [], [], []
    for dx, dy, legal, _ in primitives[1:]:
        y, x = np.nonzero(legal)
        u, v = ids[y, x], ids[y + dy, x + dx]
        valid = (u >= 0) & (v >= 0)
        u, v = u[valid], v[valid]
        us.append(u)
        vs.append(v)
        weights.append(np.full(len(u), np.linalg.norm(np.array([dx, dy]) * footprint.scale)))
    u, v, w = np.concatenate(us), np.concatenate(vs), np.concatenate(weights)
    graph = coo_matrix((np.r_[w, w], (np.r_[u, v], np.r_[v, u])), shape=(len(coords), len(coords))).tocsr()
    _, labels = connected_components(graph, directed=False)
    return coords, ids, graph, labels, (u, v, w)


def _contours(safe, ids, footprint, step):
    distance = distance_transform_edt(np.pad(safe, 1), sampling=footprint.scale[::-1])[1:-1, 1:-1]
    paths = []
    for level in np.arange(0, float(distance.max()), step):
        contours, _ = cv2.findContours((distance > level).astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
        for contour in contours:
            points = contour[:, 0, :]
            nodes = ids[points[:, 1], points[:, 0]].tolist()
            if nodes:
                paths.append(nodes)
    return sorted(paths, key=lambda p: (-len(p), p[0]))


def _stitch(loops, coords, labels, footprint, allowed, step):
    """Join nested contour cycles with two safe seams, before residual repair.

    This is a contour-splicing heuristic, not a reproduction of Fermat spirals.
    Any coverage lost at a removed seam is repaired before routing.
    """
    merged, stitches = [], 0
    for loop in loops:
        if len(loop) < 4 or len(set(loop)) != len(loop):
            merged.append(loop)
            continue
        best = None
        for index, parent in enumerate(merged):
            if len(parent) < 4 or len(set(parent)) != len(parent) or labels[parent[0]] != labels[loop[0]]:
                continue
            tree = cKDTree(coords[parent] * footprint.scale)
            distances, indices = tree.query(coords[loop] * footprint.scale)
            for j in np.argsort(distances, kind="stable")[:16]:
                if distances[j] > 2.5 * step:
                    continue
                i = int(indices[j])
                a, an = parent[i], parent[(i + 1) % len(parent)]
                for reverse in (False, True):
                    oriented = list(reversed(loop)) if reverse else loop
                    k = len(loop) - 1 - int(j) if reverse else int(j)
                    b, bn = oriented[k], oriented[(k + 1) % len(oriented)]
                    cost = np.linalg.norm((coords[a] - coords[bn]) * footprint.scale) + np.linalg.norm((coords[b] - coords[an]) * footprint.scale)
                    if best is not None and cost >= best[0]:
                        continue
                    if footprint.safe(coords[a], coords[bn], allowed) and footprint.safe(coords[b], coords[an], allowed):
                        result = parent[i + 1:] + parent[:i + 1] + oriented[k + 1:] + oriented[:k + 1]
                        best = cost, index, result
        if best is None:
            merged.append(loop)
        else:
            merged[best[1]] = best[2]
            stitches += 1
    return merged, stitches


def _add_edge(graph, a, b, coords, scale):
    graph.add_node(int(a))
    if a != b:
        graph.add_edge(int(a), int(b), weight=float(np.linalg.norm((coords[a] - coords[b]) * scale)))


def _required_graph(loops, coords, footprint, target):
    required = nx.Graph()
    covered = np.zeros_like(target)
    for loop in loops:
        edges = list(zip(loop, loop[1:] + loop[:1]))
        usable, pixels = [], []
        for a, b in edges:
            hit, exterior = footprint.pixels(coords[a], coords[b])
            if not exterior and np.all(target.ravel()[hit]):
                usable.append((a, b))
                pixels.append(hit)
        if not pixels:
            continue
        hit = np.unique(np.concatenate(pixels))
        if np.any(~covered.ravel()[hit]):
            for a, b in usable:
                _add_edge(required, a, b, coords, footprint.scale)
            covered.ravel()[hit] = True
    return required, covered


def _repair(required, covered, target, primitives, ids, coords, footprint):
    repairs = 0
    h, w = target.shape
    for flat in np.flatnonzero(target & ~covered):
        if covered.ravel()[flat]:
            continue
        y, x = divmod(int(flat), w)
        best = None
        for dx, dy, legal, offsets in primitives:
            anchors = np.array([x, y]) - offsets
            valid = (anchors[:, 0] >= 0) & (anchors[:, 0] < w) & (anchors[:, 1] >= 0) & (anchors[:, 1] < h)
            for ax, ay in anchors[valid]:
                if not legal[ay, ax]:
                    continue
                hit_xy = offsets + [ax, ay]
                hit = hit_xy[:, 1] * w + hit_xy[:, 0]
                gain = int(np.count_nonzero(~covered.ravel()[hit]))
                # Prefer existing route vertices for equal gains.
                a, b = int(ids[ay, ax]), int(ids[ay + dy, ax + dx])
                score = (gain, int(a in required) + int(b in required), int(a != b))
                if best is None or score > best[0]:
                    best = score, a, b, hit
        if best is None:
            raise RuntimeError("feasibility catalogue and residual repair disagree")
        _, a, b, hit = best
        _add_edge(required, a, b, coords, footprint.scale)
        covered.ravel()[hit] = True
        repairs += 1
    return repairs


def _connect(required, safe_graph, safe_edges, coords, footprint):
    components = list(nx.connected_components(required))
    if len(components) < 2:
        return 0
    owner = np.full(safe_graph.shape[0], -1, np.int32)
    for i, component in enumerate(components):
        owner[list(component)] = i
    sources = np.flatnonzero(owner >= 0)
    distances, predecessors, nearest = dijkstra(safe_graph, directed=False, indices=sources, min_only=True, return_predecessors=True)
    domains = np.full(len(owner), -1, np.int32)
    valid = nearest >= 0
    domains[valid] = owner[nearest[valid]]
    u, v, weight = safe_edges
    boundary = (domains[u] >= 0) & (domains[v] >= 0) & (domains[u] != domains[v])
    candidates = np.flatnonzero(boundary)
    order = candidates[np.argsort((distances[u] + weight + distances[v])[candidates], kind="stable")]
    union = nx.utils.UnionFind(range(len(components)))
    joined = 0
    for k in order:
        a, b = int(u[k]), int(v[k])
        if union[domains[a]] == union[domains[b]]:
            continue
        union.union(domains[a], domains[b])
        _add_edge(required, a, b, coords, footprint.scale)
        for node in (a, b):
            while predecessors[node] >= 0:
                previous = int(predecessors[node])
                _add_edge(required, node, previous, coords, footprint.scale)
                node = previous
        joined += 1
    return joined


def _compress(graph):
    """Collapse degree-two chains while retaining their exact geometry."""
    special = {n for n in graph if graph.degree(n) != 2}
    if not special:
        special = {min(graph)}
    result = nx.MultiGraph()
    visited = set()
    for start in sorted(special):
        result.add_node(start)
        for neighbour in sorted(graph[start]):
            key = tuple(sorted((start, neighbour)))
            if key in visited:
                continue
            points, length = [start, neighbour], graph[start][neighbour]["weight"]
            visited.add(key)
            previous, current = start, neighbour
            while current not in special:
                nxt = next(n for n in graph[current] if n != previous)
                visited.add(tuple(sorted((current, nxt))))
                length += graph[current][nxt]["weight"]
                points.append(nxt)
                previous, current = current, nxt
            result.add_edge(start, current, weight=length, points=points)
    return result


def _route(required, coords):
    paths = []
    for component in sorted(nx.connected_components(required), key=min):
        graph = _compress(required.subgraph(component))
        if not graph.number_of_edges():
            paths.append(coords[[min(component)]].astype(float))
            continue
        odd = {n for n in graph if graph.degree(n) % 2}
        start = min(graph)
        if odd and len(odd) <= 64:
            # Two dummy vertices select the open ends jointly with the matching.
            # This minimizes repeated travel on this fixed required graph.
            matching = nx.Graph()
            shortest = {}
            ordered = sorted(odd)
            for i, a in enumerate(ordered):
                distances, routes = nx.single_source_dijkstra(graph, a)
                shortest[a] = routes
                for b in ordered[i + 1:]:
                    matching.add_edge(a, b, weight=distances[b])
                matching.add_edge(-1, a, weight=0.0)
                matching.add_edge(-2, a, weight=0.0)
            pairs = nx.min_weight_matching(matching, weight="weight")
            for a, b in sorted(tuple(sorted(pair)) for pair in pairs):
                if a < 0:
                    if a == -1:
                        start = b
                    continue
                for u, v in zip(shortest[a][b][:-1], shortest[a][b][1:]):
                    data = min(graph[u][v].values(), key=lambda d: d["weight"])
                    graph.add_edge(u, v, **dict(data))
        elif odd:
            # Select distant open ends; exact for a tree, heuristic with cycles.
            distances = nx.single_source_dijkstra_path_length(graph, min(odd))
            start = max(sorted(odd), key=lambda n: distances[n])
            distances = nx.single_source_dijkstra_path_length(graph, start)
            end = max(sorted(odd - {start}), key=lambda n: distances[n])
            odd -= {start, end}
            # A bounded-memory postman heuristic: pair remaining odd junctions.
            while odd:
                a = min(odd)
                distances, routes = nx.single_source_dijkstra(graph, a)
                b = min(odd - {a}, key=lambda n: (distances[n], n))
                for u, v in zip(routes[b][:-1], routes[b][1:]):
                    data = min(graph[u][v].values(), key=lambda d: d["weight"])
                    graph.add_edge(u, v, **dict(data))
                odd -= {a, b}
        points = []
        for a, b, k in nx.eulerian_path(graph, source=start, keys=True):
            chain = graph[a][b][k]["points"]
            if chain[0] != a:
                chain = list(reversed(chain))
            points.extend(chain if not points else chain[1:])
        paths.append(coords[points].astype(float))
    return paths


def _collinear(path):
    if len(path) < 3:
        return path.copy()
    keep = [0]
    for i in range(1, len(path) - 1):
        a, b = path[i] - path[keep[-1]], path[i + 1] - path[i]
        if abs(a[0] * b[1] - a[1] * b[0]) > 1e-10 or a @ b <= 0:
            keep.append(i)
    keep.append(len(path) - 1)
    return path[keep]


def _simplify_certified(paths, target, footprint):
    """Replace staircases with longer segments when global coverage permits it."""
    counts = np.zeros(target.size, np.int32)
    for path in paths:
        edges = zip(path[:-1], path[1:]) if len(path) > 1 else [(path[0], path[0])]
        for a, b in edges:
            hit, _ = footprint.pixels(a, b)
            counts[hit] += 1
    output = []
    tolerance = footprint.radius * 0.3
    for path in paths:
        if len(path) < 3:
            output.append(path)
            continue
        result, i = [path[0]], 0
        while i < len(path) - 1:
            chosen = i + 1
            for span in (32, 16, 8, 4, 2):
                j = min(i + span, len(path) - 1)
                if j <= i + 1:
                    continue
                delta = (path[j] - path[i]) * footprint.scale
                norm = float(delta @ delta)
                if norm < 1e-12:
                    continue
                local = (path[i:j + 1] - path[i]) * footprint.scale
                projection = np.clip(local @ delta / norm, 0, 1)
                if np.max(np.linalg.norm(local - projection[:, None] * delta, axis=1)) > tolerance:
                    continue
                new, exterior = footprint.pixels(path[i], path[j])
                if exterior or np.any(~target.ravel()[new]):
                    continue
                old = [footprint.pixels(a, b)[0] for a, b in zip(path[i:j], path[i + 1:j + 1])]
                for hit in old:
                    counts[hit] -= 1
                counts[new] += 1
                affected = np.unique(np.concatenate(old))
                if np.all(counts[affected] > 0):
                    chosen = j
                    break
                counts[new] -= 1
                for hit in old:
                    counts[hit] += 1
            result.append(path[chosen])
            i = chosen
        output.append(_collinear(np.asarray(result)))
    return output


def _smooth(paths, target, footprint, fraction, minimum_segment):
    """Round corners only when the exported polyline preserves every target sample."""
    counts = np.zeros(target.size, np.int32)
    for path in paths:
        edges = zip(path[:-1], path[1:]) if len(path) > 1 else [(path[0], path[0])]
        for a, b in edges:
            hit, _ = footprint.pixels(a, b)
            counts[hit] += 1
    output, accepted = [], 0
    for path in paths:
        result = [path[0]]
        i = 1
        while i < len(path) - 1:
            a, b, c = path[i - 1:i + 2]
            u, v = (b - a) * footprint.scale, (c - b) * footprint.scale
            lengths = np.linalg.norm(u), np.linalg.norm(v)
            cosine = u @ v / (lengths[0] * lengths[1]) if min(lengths) > 1e-10 else 1.0
            if min(lengths) < 1e-10 or cosine < -0.95 or cosine >= np.cos(np.pi / 4):
                result.append(b)
                i += 1
                continue
            trim = min(fraction * min(lengths), footprint.radius * 0.5)
            q0, q1 = b - (b - a) * trim / lengths[0], b + (c - b) * trim / lengths[1]
            # The actual exported path is this polyline; no unverified spline.
            t = np.linspace(0, 1, 3)[:, None]
            curve = (1 - t) ** 2 * q0 + 2 * (1 - t) * t * b + t ** 2 * q1
            if np.min(np.linalg.norm(np.diff(curve, axis=0) * footprint.scale, axis=1)) < minimum_segment:
                result.append(b)
                i += 1
                continue
            candidate = np.vstack((a, curve, c))
            old = [footprint.pixels(a, b)[0], footprint.pixels(b, c)[0]]
            new = [footprint.pixels(x, y) for x, y in zip(candidate[:-1], candidate[1:])]
            safe = all(not exterior and np.all(target.ravel()[hit]) for hit, exterior in new)
            if safe:
                for hit in old:
                    counts[hit] -= 1
                for hit, _ in new:
                    counts[hit] += 1
                affected = np.unique(np.concatenate(old))
                safe = bool(np.all(counts[affected] > 0))
                if not safe:
                    for hit, _ in new:
                        counts[hit] -= 1
                    for hit in old:
                        counts[hit] += 1
            if safe:
                result.extend(curve)
                result.append(c)
                accepted += 1
                i += 2  # Non-overlapping edits keep accounting exact.
            else:
                result.append(b)
                i += 1
        if not np.array_equal(result[-1], path[-1]):
            result.append(path[-1])
        output.append(_collinear(np.asarray(result)))
    return output, accepted


def _order_paths(paths, footprint):
    """Greedy endpoint travel ordering; does not change contact count or ink."""
    if len(paths) < 2:
        return paths
    endpoints = np.asarray([[p[0], p[-1]] for p in paths])
    active = np.ones(len(paths), bool)
    active[0] = False
    result = [paths[0]]
    while np.any(active):
        end = result[-1][-1]
        distances = np.linalg.norm((endpoints - end) * footprint.scale, axis=-1)
        distances[~active] = np.inf
        index, reverse = divmod(int(np.argmin(distances)), 2)
        active[index] = False
        path = paths[index]
        result.append(path[::-1].copy() if reverse else path)
    return result


def path_metrics(paths, contract):
    length = repeated = 0.0
    seen, zero, sharp, minimum = set(), 0, 0, float("inf")
    line_intervals = {}
    for path in paths:
        mm = contract.pixel_to_mm(path)
        vectors = np.diff(mm, axis=0)
        lengths = np.linalg.norm(vectors, axis=1)
        total = float(lengths.sum())
        length += total
        zero += int(total < 1e-10)
        if len(lengths):
            minimum = min(minimum, float(lengths.min()))
        for a, b, distance in zip(mm[:-1], mm[1:], lengths):
            key = tuple(sorted((tuple(np.round(a, 8)), tuple(np.round(b, 8)))))
            if key in seen:
                repeated += float(distance)
            seen.add(key)
            if distance > 1e-10:
                direction = (b - a) / distance
                if direction[0] < -1e-10 or (abs(direction[0]) <= 1e-10 and direction[1] < 0):
                    direction = -direction
                offset = direction[0] * a[1] - direction[1] * a[0]
                line = (*np.round(direction, 8), round(float(offset), 8))
                line_intervals.setdefault(line, []).append(sorted((float(a @ direction), float(b @ direction))))
        for a, b, la, lb in zip(vectors[:-1], vectors[1:], lengths[:-1], lengths[1:]):
            if la * lb > 1e-12 and a @ b / (la * lb) < np.cos(np.pi / 4):
                sharp += 1
    unique_length = 0.0
    for intervals in line_intervals.values():
        start, stop = sorted(intervals)[0]
        for a, b in sorted(intervals)[1:]:
            if a > stop + 1e-8:
                unique_length += stop - start
                start, stop = a, b
            else:
                stop = max(stop, b)
        unique_length += stop - start
    travel = sum(float(np.linalg.norm(contract.pixel_to_mm(b[0]) - contract.pixel_to_mm(a[-1]))) for a, b in zip(paths[:-1], paths[1:]))
    return {"touch_downs": len(paths), "pen_down_mm": length, "pen_up_mm": travel, "exact_repeated_segment_mm": repeated,
            "collinear_retrace_mm": max(0.0, length - unique_length),
            "zero_length_routes": zero, "turns_over_45_degrees": sharp,
            "minimum_segment_mm": minimum if np.isfinite(minimum) else None,
            "waypoints": sum(len(p) for p in paths)}


def plan_continuous_coverage(binary_ink_mask, *, contract, policy=None):
    """Plan strict coverage, or return no executable paths if the grid is infeasible.

    One route is emitted per used connected safe-centre component. Contour
    selection and postman pairing are heuristics, not global optimality claims.
    No deployment or robot control occurs here.
    """
    started = perf_counter()
    target = np.asarray(binary_ink_mask, bool)
    if target.shape != contract.canvas_shape:
        raise ValueError(f"target shape {target.shape} differs from {contract.canvas_shape}")
    if not all(np.isfinite(v) for v in (contract.physical_width_mm, contract.physical_height_mm, contract.marker_width_mm)):
        raise ValueError("physical dimensions and marker width must be finite")
    policy = policy or ContinuousCoveragePolicy()
    footprint = _Footprint(contract)
    primitives, reachable = _primitives(target, footprint)
    unreachable = target & ~reachable
    metrics = {"target_pixels": int(target.sum()), "unreachable_pixels": int(unreachable.sum()),
               "certificate_model": MODEL, "robot_validated": False}
    if np.any(unreachable) or not np.any(target):
        metrics.update(path_metrics([], contract))
        metrics.update(coverage_fraction=0.0 if target.any() else 1.0, unwanted_pixels=0, planning_seconds=perf_counter() - started)
        return ContinuousCoverageResult("infeasible_on_planning_grid" if target.any() else "empty", (), np.zeros_like(target), unreachable, metrics, contract)
    coords, ids, safe_graph, labels, safe_edges = _safe_graph(primitives, footprint)
    step = contract.marker_width_mm * policy.stepover_fraction
    loops = _contours(primitives[0][2], ids, footprint, step)
    stitches = 0
    if policy.stitch_contours:
        loops, stitches = _stitch(loops, coords, labels, footprint, target, step)
    required, covered = _required_graph(loops, coords, footprint, target)
    repairs = _repair(required, covered, target, primitives, ids, coords, footprint)
    joins = _connect(required, safe_graph, safe_edges, coords, footprint)
    paths = [_collinear(p) for p in _route(required, coords)]
    paths = _simplify_certified(paths, target, footprint)
    before = path_metrics(paths, contract)
    rounded = 0
    if policy.smooth:
        paths, rounded = _smooth(paths, target, footprint, policy.corner_fraction, policy.minimum_curve_segment_mm)
    paths = _order_paths(paths, footprint)
    # Re-render the final exported geometry, including every join and repair.
    coverage = render_swept_paths(paths, contract)
    if np.any(target & ~coverage) or np.any(coverage & ~target):
        raise RuntimeError("final coverage certificate failed")
    if any(not footprint.safe(a, b, target) for p in paths for a, b in zip(p[:-1], p[1:])):
        raise RuntimeError("final path leaves the allowed raster domain")
    metrics.update(path_metrics(paths, contract))
    metrics.update(coverage_fraction=1.0, unwanted_pixels=0, contour_stitches=stitches,
                   residual_primitives=repairs, safe_graph_joins=joins, rounded_corners=rounded,
                   turns_before_smoothing=before["turns_over_45_degrees"],
                   marker_width_pixels=list(contract.marker_width_pixels),
                   safe_centre_components=int(labels.max() + 1),
                   used_safe_centre_components=len(set(labels[list(required)])),
                   planning_seconds=perf_counter() - started)
    return ContinuousCoverageResult("complete_on_planning_grid", tuple(paths), coverage, unreachable, metrics, contract)
