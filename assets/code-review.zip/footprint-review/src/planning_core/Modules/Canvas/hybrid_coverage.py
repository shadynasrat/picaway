"""Experimental hybrid coverage with guarded route improvement and grid auditing.

V1 stays frozen for comparisons. Normal planning covers a refined grid, allowing
localized spill to repair otherwise unreachable detail. ``allow_detail_spill=False``
retains strict rejection. ``audit_scale=1`` requests a diagnostic-only run.
Neither mode authorizes robot execution or certifies continuous image areas.
"""

from dataclasses import dataclass, field
from time import perf_counter

import networkx as nx
import numpy as np
from scipy.ndimage import distance_transform_edt

from . import continuous_coverage as v1
from .centerline_extractor import _zhang_suen
from .drawing_contract import DrawingContract
from .coverage_routing import coverage_envelope, order_routes, smooth_traversal


VERSION = "footprint-1.0.0"


@dataclass(frozen=True)
class HybridPolicy:
    audit_scale: int = 2
    minimum_marker_samples: float = 4.0
    maximum_refinement_scale: int = 8
    minimum_segment_mm: float = .15
    shortcut_spans: tuple[int, ...] = (64, 32, 16, 8, 4, 2)
    curve_fitting: bool = True
    hybrid_candidates: bool = True
    allow_detail_spill: bool = True

    def __post_init__(self):
        if not isinstance(self.allow_detail_spill, bool):
            raise ValueError("allow_detail_spill must be a boolean")
        if isinstance(self.audit_scale, bool) or not isinstance(self.audit_scale, int) or self.audit_scale < 1:
            raise ValueError("audit_scale must be a positive integer")
        if not np.isfinite(self.minimum_marker_samples) or self.minimum_marker_samples < 1:
            raise ValueError("minimum_marker_samples must be finite and at least one")
        if not np.isfinite(self.minimum_segment_mm) or self.minimum_segment_mm <= 0:
            raise ValueError("minimum_segment_mm must be finite and positive")
        if isinstance(self.maximum_refinement_scale, bool) or not isinstance(self.maximum_refinement_scale, int) or self.maximum_refinement_scale < self.audit_scale:
            raise ValueError("maximum_refinement_scale must be an integer >= audit_scale")
        if not self.shortcut_spans or any(isinstance(s, bool) or not isinstance(s, int) or s < 2 for s in self.shortcut_spans):
            raise ValueError("shortcut_spans must contain integers >= 2")


@dataclass
class HybridResult:
    status: str
    paths: tuple
    contract: DrawingContract
    metrics: dict
    audit: dict
    candidates: list = field(default_factory=list)

    def to_dict(self):
        return {"pipeline_version": VERSION, "experimental": True, "robot_ready": False,
                "status": self.status, "contract": self.contract.to_dict(),
                "metrics": self.metrics, "audit": self.audit, "candidates": self.candidates,
                "paths": [{"path_id": i, "points": p.tolist(), "points_mm": self.contract.pixel_to_mm(p).tolist()}
                          for i, p in enumerate(self.paths)]}


def _shape_metrics(points, scale):
    points = np.asarray(points, float)
    if len(points) < 2:
        return 0.0, 0, 0.0
    vectors = np.diff(points, axis=0) * scale
    lengths = np.linalg.norm(vectors, axis=1)
    distance = float(lengths.sum())
    valid = lengths > 1e-10
    vectors, lengths = vectors[valid], lengths[valid]
    if len(lengths) < 2:
        return distance, 0, 0.0
    cosine = np.sum(vectors[:-1] * vectors[1:], axis=1) / (lengths[:-1] * lengths[1:])
    return distance, int(np.count_nonzero(cosine < np.cos(np.pi / 4) - 1e-9)), float(np.arccos(np.clip(cosine, -1, 1)).sum())


def route_metrics(paths, contract):
    scale = np.asarray([contract.millimetres_per_pixel_x, contract.millimetres_per_pixel_y])
    distance = turns = angle = tiny = zero = 0
    for p in paths:
        length, sharp, bend = _shape_metrics(p, scale)
        distance += length
        turns += sharp
        angle += bend
        lengths = np.linalg.norm(np.diff(p, axis=0) * scale, axis=1)
        tiny += int(np.count_nonzero((lengths > 1e-10) & (lengths < .1)))
        zero += int(length < 1e-10)
    air = sum(float(np.linalg.norm((b[0] - a[-1]) * scale)) for a, b in zip(paths[:-1], paths[1:]))
    return {"touch_downs": len(paths), "pen_down_mm": float(distance), "pen_up_mm": air,
            "waypoints": sum(len(p) for p in paths), "stable_turns_over_45_degrees": int(turns),
            "total_pen_down_turn_radians": float(angle), "nonzero_segments_below_0_1_mm": tiny,
            "zero_length_routes": zero}


GUARDED_METRICS = ("touch_downs", "pen_down_mm", "pen_up_mm", "waypoints",
                   "stable_turns_over_45_degrees", "total_pen_down_turn_radians",
                   "nonzero_segments_below_0_1_mm", "zero_length_routes")


def no_regression(candidate, reference):
    continuous = {"pen_down_mm", "pen_up_mm", "total_pen_down_turn_radians"}
    return all(candidate[k] <= reference[k] + (1e-7 * max(1., reference[k]) if k in continuous else 0.) for k in GUARDED_METRICS)


def _clean(path):
    p = np.asarray(path, float).reshape(-1, 2)
    if len(p) > 1:
        p = p[np.r_[True, np.any(np.abs(np.diff(p, axis=0)) > 1e-10, axis=1)]]
    return v1._collinear(p)


class _CoverageLedger:
    """Per-segment coverage accounting; replacement cannot remove the last pass."""
    def __init__(self, paths, target, footprint, required=None):
        self.footprint, self.target = footprint, target
        self.required = target if required is None else required
        self.counts = np.zeros(target.size, np.int32)
        self.hits = []
        for path in paths:
            sweeps = [footprint.pixels(a, b) for a, b in (zip(path[:-1], path[1:]) if len(path) > 1 else [(path[0], path[0])])]
            if any(exterior or np.any(~target.ravel()[hit]) for hit, exterior in sweeps):
                raise ValueError("input route leaves the allowed region")
            hits = [hit for hit, _ in sweeps]
            for hit in hits:
                self.counts[hit] += 1
            self.hits.append(hits)

    def replace(self, old_hits, points, *, commit=True):
        new_hits = []
        for a, b in zip(points[:-1], points[1:]):
            hit, exterior = self.footprint.pixels(a, b)
            if exterior or np.any(~self.target.ravel()[hit]):
                return None
            new_hits.append(hit)
        old_ids, multiplicity = np.unique(np.concatenate(old_hits), return_counts=True)
        new_ids, new_counts = np.unique(np.concatenate(new_hits), return_counts=True)
        last_pass = old_ids[(self.counts[old_ids] == multiplicity) & self.required.ravel()[old_ids]]
        if not np.all(np.isin(last_pass, new_ids)):
            return None
        if commit:
            self.counts[old_ids] -= multiplicity
            self.counts[new_ids] += new_counts
        return new_hits


class _RefinedReference:
    """Protect covered fine samples and forbid new white contact, including outside."""
    def __init__(self, paths, target, contract, policy):
        self.factor = 2
        while min(contract.marker_width_pixels) * self.factor < policy.minimum_marker_samples:
            self.factor *= 2
        if self.factor > policy.maximum_refinement_scale:
            raise ValueError("reference guard exceeds maximum refinement scale")
        work, fine = _refine(target, contract, self.factor)
        self.pad = int(np.ceil(max(fine.marker_width_pixels))) + 2
        work = np.pad(work, self.pad)
        self.contract = DrawingContract("reference-guard", work.shape[1], work.shape[0],
                        work.shape[1]*fine.millimetres_per_pixel_x,
                        work.shape[0]*fine.millimetres_per_pixel_y, contract.marker_width_mm)
        mapped = [self.map(p) for p in paths]
        covered = v1.render_swept_paths(mapped, self.contract)
        self.required = covered & work
        self.allowed = covered | work
        self.ledger = _CoverageLedger(mapped, self.allowed, v1._Footprint(self.contract), self.required)

    def map(self, points):
        return (np.asarray(points)+.5)*self.factor-.5+self.pad

    def valid(self, paths):
        covered = v1.render_swept_paths([self.map(p) for p in paths], self.contract)
        return not np.any(self.required & ~covered) and not np.any(covered & ~self.allowed)


def _curve(points, scale):
    """Least-squares quadratic over a complete span, with fixed endpoints."""
    physical = points * scale
    distances = np.r_[0., np.cumsum(np.linalg.norm(np.diff(physical, axis=0), axis=1))]
    if distances[-1] < 1e-10:
        return None
    t = distances / distances[-1]
    weights = 2 * t * (1 - t)
    denominator = float(weights @ weights)
    if denominator < 1e-12:
        return None
    residual = physical - (1 - t[:, None]) ** 2 * physical[0] - t[:, None] ** 2 * physical[-1]
    control = np.sum(weights[:, None] * residual, axis=0) / denominator
    u = np.linspace(0, 1, min(5, len(points) - 1))[:, None]
    return ((1 - u) ** 2 * physical[0] + 2 * (1 - u) * u * control + u ** 2 * physical[-1]) / scale


def improve_routes(paths, target, contract, policy=None):
    """Remove redundant excursions and fit whole spans with a coverage ledger."""
    policy = policy or HybridPolicy(audit_scale=1)
    original = [np.asarray(p, float).copy() for p in paths]
    paths = [_clean(p) for p in original]
    footprint = v1._Footprint(contract)
    ledger = _CoverageLedger(paths, target, footprint)
    if np.any(target.ravel() & (ledger.counts == 0)):
        raise ValueError("improvement requires a complete input plan")
    try:
        refined = _RefinedReference(paths, target, contract, policy)
    except ValueError:
        return original, {"shortcuts": 0, "fitted_spans": 0, "guard_fallback": True,
                          "reason": "refined reference guard unavailable"}
    shortcuts = curves = 0
    for index, path in enumerate(paths):
        if len(path) < 3:
            continue
        # Build the new route left-to-right; original suffixes are never rescanned.
        hits = ledger.hits[index]
        output, i = [path[0]], 0
        while i < len(path) - 1:
            accepted = False
            for span in policy.shortcut_spans:
                j = min(i + span, len(path) - 1)
                if j <= i + 1:
                    continue
                old = path[i:j + 1]
                left = [output[-2]] if len(output) > 1 else []
                right = [path[j + 1]] if j + 1 < len(path) else []
                before = _shape_metrics(np.asarray(left + old.tolist() + right), footprint.scale)
                candidates = [(False, np.asarray([path[i], path[j]]))]
                if policy.curve_fitting and j - i >= 8:
                    curve = _curve(old, footprint.scale)
                    if curve is not None:
                        candidates.append((True, curve))
                for fitted, proposed in candidates:
                    lengths = np.linalg.norm(np.diff(proposed, axis=0) * footprint.scale, axis=1)
                    if np.any((lengths > 1e-10) & (lengths < policy.minimum_segment_mm)):
                        continue
                    after = _shape_metrics(np.asarray(left + proposed.tolist() + right), footprint.scale)
                    if any(a > b + 1e-8 * max(1., b) for a, b in zip(after, before)):
                        continue
                    if ledger.replace(hits[i:j], proposed, commit=False) is None:
                        continue
                    fine_hits = refined.ledger.hits[index][i:j]
                    mapped = refined.map(proposed)
                    if refined.ledger.replace(fine_hits, mapped, commit=False) is None:
                        continue
                    ledger.replace(hits[i:j], proposed)
                    refined.ledger.replace(fine_hits, mapped)
                    output.extend(proposed[1:])
                    i = j
                    curves += int(fitted)
                    shortcuts += int(not fitted)
                    accepted = True
                    break
                if accepted:
                    break
            if not accepted:
                output.append(path[i + 1])
                i += 1
        paths[index] = _clean(np.asarray(output))
    reference, candidate = route_metrics(original, contract), route_metrics(paths, contract)
    coverage = v1.render_swept_paths(paths, contract)
    valid = np.array_equal(coverage, target) and all(
        footprint.safe(a, b, target) for p in paths
        for a, b in (zip(p[:-1], p[1:]) if len(p) > 1 else [(p[0], p[0])]))
    if not valid or not no_regression(candidate, reference) or not refined.valid(paths):
        return original, {"shortcuts": 0, "fitted_spans": 0, "guard_fallback": True}
    return paths, {"shortcuts": shortcuts, "fitted_spans": curves, "guard_fallback": False,
                   "reference_guard_scale": refined.factor}


def _bounded_route(required, coords):
    """Parity correction on a spanning tree avoids quadratic large-graph pairing."""
    paths, fallbacks = [], 0
    for nodes in sorted(nx.connected_components(required), key=min):
        subgraph = required.subgraph(nodes)
        graph = v1._compress(subgraph)
        odd = {n for n in graph if graph.degree(n) % 2}
        if len(odd) <= 64:
            paths.extend(v1._route(subgraph, coords))
            continue
        fallbacks += 1
        tree = nx.minimum_spanning_tree(graph, weight="weight")
        distance = nx.single_source_dijkstra_path_length(tree, min(odd))
        start = max(sorted(odd), key=lambda n: distance[n])
        distance = nx.single_source_dijkstra_path_length(tree, start)
        end = max(sorted(odd - {start}), key=lambda n: distance[n])
        parity = {n: int(n in odd.symmetric_difference({start, end})) for n in tree}
        traversal = list(nx.dfs_edges(tree, source=start))
        for parent, child in reversed(traversal):
            if parity[child]:
                data = min(tree[parent][child].values(), key=lambda d: d["weight"])
                graph.add_edge(parent, child, **dict(data))
                parity[parent] ^= 1
        points = []
        for a, b, key in nx.eulerian_path(graph, source=start, keys=True):
            chain = graph[a][b][key]["points"]
            if chain[0] != a:
                chain = list(reversed(chain))
            points.extend(chain if not points else chain[1:])
        paths.append(coords[points].astype(float))
    return paths, fallbacks


def _hybrid_seed(target, contract):
    f = v1._Footprint(contract)
    primitives, _ = v1._primitives(target, f)
    coords, ids, safe_graph, _, safe_edges = v1._safe_graph(primitives, f)
    safe = primitives[0][2]
    depth = distance_transform_edt(np.pad(safe, 1), sampling=f.scale[::-1])[1:-1, 1:-1]
    core = depth > contract.marker_width_mm
    broad = (distance_transform_edt(~core, sampling=f.scale[::-1]) <= contract.marker_width_mm * 1.5) & safe if np.any(core) else np.zeros_like(safe)
    loops = v1._contours(safe, ids, f, contract.marker_width_mm * .75)
    all_contours, _ = v1._required_graph(loops, coords, f, target)
    required = nx.Graph()
    for a, b in all_contours.edges:
        if broad[coords[a, 1], coords[a, 0]] and broad[coords[b, 1], coords[b, 0]]:
            v1._add_edge(required, a, b, coords, f.scale)
    skeleton = _zhang_suen(safe)
    for dx, dy, legal, _ in primitives[1:]:
        y, x = np.nonzero(legal)
        keep = skeleton[y, x] & skeleton[y + dy, x + dx]
        for a, b in zip(ids[y[keep], x[keep]], ids[y[keep] + dy, x[keep] + dx]):
            v1._add_edge(required, a, b, coords, f.scale)
    required.add_nodes_from(ids[skeleton].tolist())
    seeds = [coords[[a, b]] for a, b in required.edges]
    seeds += [coords[[n]] for n in required if required.degree(n) == 0]
    coverage = v1.render_swept_paths(seeds, contract)
    repairs = v1._repair(required, coverage, target, primitives, ids, coords, f)
    joins = v1._connect(required, safe_graph, safe_edges, coords, f)
    paths, bounded = _bounded_route(required, coords)
    paths = v1._order_paths([_clean(p) for p in paths], f)
    return paths, {"residual_primitives": repairs, "safe_joins": joins, "bounded_parity_components": bounded,
                   "broad_centre_pixels": int(broad.sum()), "skeleton_pixels": int(skeleton.sum())}


def _refine(target, contract, factor):
    mask = target.repeat(factor, axis=0).repeat(factor, axis=1)
    refined = DrawingContract(contract.profile_id + f"-grid-{factor}", contract.pixel_width * factor,
                              contract.pixel_height * factor, contract.physical_width_mm,
                              contract.physical_height_mm, contract.marker_width_mm)
    return mask, refined


def _audit_grid(binary_ink_mask, contract, policy):
    target = np.asarray(binary_ink_mask, bool)
    if target.shape != contract.canvas_shape:
        raise ValueError("target shape and drawing contract differ")
    if not all(np.isfinite(v) for v in (contract.marker_width_mm, contract.physical_width_mm, contract.physical_height_mm)):
        raise ValueError("physical dimensions must be finite")
    factor = policy.audit_scale
    if factor > 1:
        while min(contract.marker_width_pixels) * factor < policy.minimum_marker_samples:
            factor *= 2
    if factor > policy.maximum_refinement_scale:
        return None, None, {"status": "insufficient_grid_resolution", "required_scale": factor,
                            "maximum_scale": policy.maximum_refinement_scale}
    work, calibration = _refine(target, contract, factor)
    _, reachable = v1._primitives(work, v1._Footprint(calibration))
    missing = work & ~reachable
    audit = {"scale": factor, "source_marker_width_pixels": list(contract.marker_width_pixels),
             "planning_marker_width_pixels": list(calibration.marker_width_pixels),
             "unreachable_pixels": int(missing.sum()), "target_pixels": int(work.sum()),
             "scope": "pixel-centre swept disk on nearest-neighbour refined source cells; not continuous-area or physical certification"}
    if np.any(missing) or not np.any(work):
        audit["unreachable_source_pixels"] = int(np.any(missing.reshape(target.shape[0], factor, target.shape[1], factor), axis=(1, 3)).sum())
        status = "empty" if not np.any(work) else "infeasible_on_refined_grid" if factor > 1 else "infeasible_on_diagnostic_grid"
        audit["status"] = status
    else:
        audit["status"] = "reachable_on_refined_grid" if factor > 1 else "reachable_on_diagnostic_grid"
    return work, calibration, audit


def audit_hybrid_coverage(binary_ink_mask, *, contract, policy=None):
    """Preflight reachability only; does not generate or certify a route."""
    _, _, audit = _audit_grid(binary_ink_mask, contract, policy or HybridPolicy())
    return audit


def plan_hybrid_coverage(binary_ink_mask, *, contract, policy=None, reference_paths=None):
    """Generate, improve and select complete plans; reject unresolved refined ink.

    ``reference_paths`` is an optional checked benchmark reference in source
    pixel coordinates, never trusted without footprint revalidation.
    """
    started = perf_counter()
    policy = policy or HybridPolicy()
    if policy.allow_detail_spill:
        return _plan_coverage_first(binary_ink_mask, contract, policy)
    work, calibration, audit = _audit_grid(binary_ink_mask, contract, policy)
    if not audit["status"].startswith("reachable_"):
        return HybridResult(audit["status"], (), contract,
                            {**route_metrics([], contract), "planning_seconds": perf_counter() - started}, audit)
    factor = audit["scale"]
    if reference_paths is None or factor > 1:
        reference = list(v1.plan_continuous_coverage(work, contract=calibration).paths)
    else:
        reference = [np.asarray(p, float).copy() for p in reference_paths]
    if any(p.ndim != 2 or p.shape[1] != 2 or len(p) == 0 or not np.all(np.isfinite(p)) for p in reference):
        raise ValueError("reference paths must contain finite nonempty Nx2 coordinates")
    f = v1._Footprint(calibration)
    if not np.array_equal(v1.render_swept_paths(reference, calibration), work) or any(
        not f.safe(a, b, work) for p in reference
        for a, b in (zip(p[:-1], p[1:]) if len(p) > 1 else [(p[0], p[0])])):
        raise ValueError("reference plan is incomplete or leaves the allowed region")
    original = route_metrics(reference, calibration)
    try:
        refined_reference = _RefinedReference(reference, work, calibration, policy)
    except ValueError:
        refined_reference = None
    candidates = []
    paths, details = improve_routes(reference, work, calibration, policy)
    metrics = route_metrics(paths, calibration)
    candidates.append({"name": "improved_reference", "metrics": metrics, **details})
    chosen, selected = paths, "improved_reference"
    if policy.hybrid_candidates:
        alternative, seed_details = _hybrid_seed(work, calibration)
        alternative, details = improve_routes(alternative, work, calibration, policy)
        alternative_metrics = route_metrics(alternative, calibration)
        fine_accepted = refined_reference is not None and refined_reference.valid(alternative)
        accepted = no_regression(alternative_metrics, original) and fine_accepted
        candidates.append({"name": "thin_skeleton_broad_contours", "metrics": alternative_metrics,
                           "eligible": accepted, "refined_reference_guard_passed": fine_accepted,
                           **seed_details, **details})
        if accepted and (alternative_metrics["touch_downs"], alternative_metrics["pen_down_mm"], alternative_metrics["total_pen_down_turn_radians"]) < (metrics["touch_downs"], metrics["pen_down_mm"], metrics["total_pen_down_turn_radians"]):
            chosen, selected, metrics = alternative, "thin_skeleton_broad_contours", alternative_metrics
    # Map refinement centres back into the source coordinate convention.
    exported = tuple((p + .5) / factor - .5 for p in chosen)
    reimported = [(p + .5) * factor - .5 for p in exported]
    if not np.array_equal(v1.render_swept_paths(reimported, calibration), work):
        raise RuntimeError("exported geometry failed coverage validation")
    metrics.update(selected_candidate=selected, coverage_fraction=1.0, unwanted_pixels=0,
                   reference_metrics=original, guarded_metrics=list(GUARDED_METRICS),
                   planning_seconds=perf_counter() - started, robot_validated=False)
    return HybridResult("complete_on_refined_grid" if factor > 1 else "diagnostic_coarse_only",
                        exported, contract, metrics, audit, candidates)


def _plan_coverage_first(target, contract, policy):
    """Cover required samples with localized spill and independently routed seeds.

    Padding accounts for contact outside the image. No V1 reference or wall-clock
    cutoff is used. The original strict planner remains available for comparisons.
    """
    started = perf_counter()
    work, calibration, audit = _audit_grid(target, contract, policy)
    if work is None or not np.any(work):
        return HybridResult(audit["status"], (), contract, route_metrics([], contract), audit)
    factor = audit["scale"]
    pad = int(np.ceil(max(calibration.marker_width_pixels)))+2
    required = np.pad(work, pad)
    h, w = required.shape
    padded = DrawingContract("coverage-first-padded", w, h,
                             w*calibration.millimetres_per_pixel_x,
                             h*calibration.millimetres_per_pixel_y, contract.marker_width_mm)
    allowed, spill = coverage_envelope(required, padded)
    paths, seed = _hybrid_seed(allowed, padded)
    before = route_metrics(paths, padded)
    paths, improvement = improve_routes(paths, allowed, padded, policy)
    scale = np.array([padded.millimetres_per_pixel_x, padded.millimetres_per_pixel_y])
    smoother = []
    for path in paths:
        proposal = _clean(smooth_traversal(path, scale))
        # Same segment multiset before cleaning; reject any motion regression.
        smoother.append(proposal if no_regression(route_metrics([proposal], padded),
                                                   route_metrics([path], padded)) else path)
    paths = order_routes(smoother, padded)
    painted = v1.render_swept_paths(paths, padded)
    if np.any(required & ~painted) or np.any(painted & ~allowed):
        raise RuntimeError("coverage-first routing changed required coverage or spill envelope")
    exported = tuple((p-pad+.5)/factor-.5 for p in paths)
    mapped = [(p+.5)*factor-.5+pad for p in exported]
    if not np.array_equal(v1.render_swept_paths(mapped, padded), painted):
        raise RuntimeError("coverage-first export changed swept coverage")
    metrics = route_metrics(exported, contract)
    metrics.update(coverage_fraction=float((painted & required).sum()/required.sum()),
                   unwanted_pixels=int((painted & ~required).sum()),
                   reference_metrics=before, planning_seconds=perf_counter()-started,
                   robot_validated=False, **spill)
    audit.update(coverage_first=True, original_strict_status=audit["status"],
                 padding_samples=pad, spill_minimum_proven=False)
    return HybridResult("complete_with_spill_on_refined_grid" if factor > 1 else "diagnostic_coverage_first",
                        exported, contract, metrics, audit,
                        [{"name": "coverage_first_routing", **seed, **improvement}])
