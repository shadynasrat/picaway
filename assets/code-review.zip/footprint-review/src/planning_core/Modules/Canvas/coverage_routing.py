"""Coverage-first envelope construction and geometry-preserving route ordering.

Spill selection is a discrete greedy heuristic, not a minimum-spill proof.
"""
import heapq
import cv2
import networkx as nx
import numpy as np
from . import continuous_coverage as cc


def coverage_envelope(target, contract):
    """Add stamp footprints only to repair samples unreachable without spill."""
    footprint = cc._Footprint(contract)
    primitives, reachable = cc._primitives(target, footprint)
    missing = target & ~reachable
    allowed = target.copy()
    if not missing.any():
        return allowed, {"repair_stamps": 0, "added_white_samples": 0}
    offsets = primitives[0][3]
    rx, ry = np.max(np.abs(offsets), axis=0)
    kernel = np.zeros((2*ry+1, 2*rx+1), np.float64)
    kernel[offsets[:, 1]+ry, offsets[:, 0]+rx] = 1
    gains = cv2.filter2D(missing.astype(float), -1, kernel, borderType=cv2.BORDER_CONSTANT)
    spill = len(offsets)-cv2.filter2D(target.astype(float), -1, kernel, borderType=cv2.BORDER_CONSTANT)
    # Centres stay on target ink; no permission to bridge arbitrary white gaps.
    ys, xs = np.nonzero(target & (gains > .5))
    heap = [((spill[y, x]+1)/round(gains[y, x]), int(y), int(x)) for y, x in zip(ys, xs)]
    heapq.heapify(heap)
    stamps, centres = 0, []
    while missing.any():
        _, y, x = heapq.heappop(heap)
        xx, yy = x+offsets[:, 0], y+offsets[:, 1]
        if np.any((xx < 0) | (xx >= target.shape[1]) | (yy < 0) | (yy >= target.shape[0])):
            raise ValueError("coverage envelope requires a padded canvas")
        gain = int(missing[yy, xx].sum())
        if not gain:
            continue
        cost = (spill[y, x]+1)/gain
        if heap and cost > heap[0][0]+1e-12:
            heapq.heappush(heap, (cost, y, x))
            continue
        allowed[yy, xx] = True
        missing[yy, xx] = False
        stamps += 1
        centres.append((x, y))
    # A connected thin detail should be drawn as a stroke, not disconnected
    # stamps. Connect repairs along original target centres, never across gaps.
    # The full-width sweep may spill locally around these narrow black details.
    point_footprint = cc._Footprint(contract)
    point_footprint.radius = min(footprint.scale)*1e-5
    point_primitives, _ = cc._primitives(target, point_footprint)
    coords, ids, graph, _, edges = cc._safe_graph(point_primitives, point_footprint)
    required = nx.Graph()
    required.add_nodes_from(int(ids[y, x]) for x, y in centres)
    safe_coords, _, _, safe_labels, _ = cc._safe_graph(primitives, footprint)
    if len(safe_coords):
        _, representatives = np.unique(safe_labels, return_index=True)
        required.add_nodes_from(int(ids[y, x]) for x, y in safe_coords[representatives])
    # Existing full-width connections cost no additional spill. Represent them
    # as logical groups before choosing new detail links; never render these
    # virtual edges as straight strokes.
    allowed_primitives, _ = cc._primitives(allowed, footprint)
    _, allowed_ids, _, allowed_labels, _ = cc._safe_graph(allowed_primitives, footprint)
    groups = {}
    for node in list(required):
        x, y = coords[node]
        component = int(allowed_labels[allowed_ids[y, x]])
        if component in groups:
            required.add_edge(groups[component], node)
        else:
            groups[component] = node
    virtual = {frozenset((a, b)) for a, b in required.edges}
    joins = cc._connect(required, graph, edges, coords, footprint)
    for a, b in required.edges:
        if frozenset((a, b)) in virtual:
            continue
        hit, exterior = footprint.pixels(coords[a], coords[b])
        if exterior:
            raise ValueError("detail connectors require a padded canvas")
        allowed.ravel()[hit] = True
    return allowed, {"repair_stamps": stamps, "detail_connections": joins,
                     "added_white_samples": int((allowed & ~target).sum()),
                     "spill_selection": "greedy stamp repair; not globally minimal"}


def _entry(path, previous, scale):
    """Reorient an open stroke or rotate a closed stroke at an existing vertex."""
    if len(path) > 2 and np.array_equal(path[0], path[-1]):
        points = path[:-1]
        k = int(np.argmin(np.linalg.norm((points-previous)*scale, axis=1)))
        return np.concatenate((points[k:], points[:k], points[k:k+1]))
    if np.linalg.norm((path[-1]-previous)*scale) < np.linalg.norm((path[0]-previous)*scale):
        return path[::-1].copy()
    return path.copy()


def order_routes(paths, contract):
    """Nearest reachable entry followed by convergent reversal and entry refinement.

    Stroke geometry and contact count are unchanged. Retain the input if travel
    does not improve; the first stroke is fixed because no robot start was given.
    """
    original = [np.asarray(p, float).copy() for p in paths]
    if len(original) < 2:
        return original
    scale = np.array([contract.millimetres_per_pixel_x, contract.millimetres_per_pixel_y])
    def length(seq):
        return sum(np.linalg.norm((b[0]-a[-1])*scale) for a, b in zip(seq, seq[1:]))
    remaining, result = original[1:], [original[0]]
    while remaining:
        choices = [_entry(p, result[-1][-1], scale) for p in remaining]
        k = min(range(len(choices)), key=lambda i: np.linalg.norm((choices[i][0]-result[-1][-1])*scale))
        result.append(choices[k]); remaining.pop(k)
    # Reversing a block also reverses every stroke, preserving every ink segment.
    changed = True
    while changed:
        changed = False
        starts = np.asarray([p[0] for p in result])*scale
        ends = np.asarray([p[-1] for p in result])*scale
        for i in range(1, len(result)):
            j0 = i
            while j0 < len(result):
                # Evaluate the same reversal moves in a vector batch, preserving
                # first-improvement order and the convergent search, without a
                # Python distance calculation for every pair of strokes.
                a, b = ends[i-1], starts[i]
                old = np.full(len(result)-j0, np.linalg.norm(a-b))
                new = np.linalg.norm(ends[j0:]-a, axis=1)
                old[:-1] += np.linalg.norm(ends[j0:-1]-starts[j0+1:], axis=1)
                new[:-1] += np.linalg.norm(starts[j0+1:]-b, axis=1)
                choices = np.flatnonzero(new < old-1e-7)
                if not len(choices):
                    break
                j = j0+int(choices[0])
                result[i:j+1] = [p[::-1].copy() for p in result[i:j+1][::-1]]
                old_starts = starts[i:j+1].copy()
                starts[i:j+1] = ends[i:j+1][::-1]
                ends[i:j+1] = old_starts[::-1]
                changed = True
                j0 = j+1
        for i in range(1, len(result)):
            p = result[i]
            if len(p) <= 2 or not np.array_equal(p[0], p[-1]):
                continue
            points = p[:-1]
            costs = np.linalg.norm((points-result[i-1][-1])*scale, axis=1)
            if i+1 < len(result):
                costs += np.linalg.norm((points-result[i+1][0])*scale, axis=1)
            k = int(np.argmin(costs))
            if costs[k] < costs[0]-1e-7:
                result[i] = np.concatenate((points[k:], points[:k], points[k:k+1]))
                changed = True
    return result if length(result) < length(original)-1e-7 else original


def smooth_traversal(path, scale):
    """Euler traversal of the same segment multiset, preferring shallow turns."""
    if len(path) < 4:
        return path.copy()
    points, inverse = np.unique(path, axis=0, return_inverse=True)
    adjacency = [[] for _ in points]
    for e, (a, b) in enumerate(zip(inverse[:-1], inverse[1:])):
        adjacency[a].append((b, e)); adjacency[b].append((a, e))
    used = np.zeros(len(path)-1, bool)
    stack, output = [int(inverse[0])], []
    while stack:
        node = stack[-1]
        candidates = [(b, e) for b, e in adjacency[node] if not used[e]]
        if not candidates:
            output.append(stack.pop())
            continue
        incoming = (points[node]-points[stack[-2]])*scale if len(stack) > 1 else np.zeros(2)
        def key(edge):
            delta = (points[edge[0]]-points[node])*scale
            norm = np.linalg.norm(delta)*np.linalg.norm(incoming)
            return -float(incoming@delta)/norm if norm else 0.
        nxt, edge = min(candidates, key=key)
        used[edge] = True; stack.append(nxt)
    return points[output[::-1]]
