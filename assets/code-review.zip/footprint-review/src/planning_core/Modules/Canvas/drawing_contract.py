"""Physical-unit drawing contracts used by waypoint extraction."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np


@dataclass(frozen=True)
class DrawingContract:
    """A named canvas and fixed-marker calibration profile.

    Pixel coordinates use the same top-left origin as the existing image
    pipeline.  The physical extent intentionally follows the repository's
    serializer convention: one canvas pixel is ``physical_extent / pixel_extent``
    millimetres rather than using ``pixel_extent - 1``.
    """

    profile_id: str
    pixel_width: int
    pixel_height: int
    physical_width_mm: float
    physical_height_mm: float
    marker_width_mm: float

    def __post_init__(self) -> None:
        if not self.profile_id.strip():
            raise ValueError("profile_id must not be empty")
        if self.pixel_width <= 0 or self.pixel_height <= 0:
            raise ValueError("pixel dimensions must be positive")
        if self.physical_width_mm <= 0 or self.physical_height_mm <= 0:
            raise ValueError("physical dimensions must be positive")
        if self.marker_width_mm <= 0:
            raise ValueError("marker_width_mm must be positive")

    @property
    def millimetres_per_pixel_x(self) -> float:
        return self.physical_width_mm / self.pixel_width

    @property
    def millimetres_per_pixel_y(self) -> float:
        return self.physical_height_mm / self.pixel_height

    @property
    def marker_radius_mm(self) -> float:
        return self.marker_width_mm / 2.0

    @property
    def marker_width_pixels(self) -> tuple[float, float]:
        return (
            self.marker_width_mm / self.millimetres_per_pixel_x,
            self.marker_width_mm / self.millimetres_per_pixel_y,
        )

    @property
    def canvas_shape(self) -> tuple[int, int]:
        return (self.pixel_height, self.pixel_width)

    def pixel_to_mm(
        self, points: Sequence[Sequence[float]] | np.ndarray
    ) -> np.ndarray:
        """Convert ``[..., 2]`` ``(x, y)`` pixel points into millimetres."""

        values = np.asarray(points, dtype=float)
        if values.shape[-1] != 2:
            raise ValueError("points must have a final dimension of size 2")
        scale = np.asarray(
            [self.millimetres_per_pixel_x, self.millimetres_per_pixel_y],
            dtype=float,
        )
        return values * scale

    def mm_to_pixel(
        self, points: Sequence[Sequence[float]] | np.ndarray
    ) -> np.ndarray:
        """Convert ``[..., 2]`` ``(x, y)`` millimetre points into pixels."""

        values = np.asarray(points, dtype=float)
        if values.shape[-1] != 2:
            raise ValueError("points must have a final dimension of size 2")
        scale = np.asarray(
            [self.millimetres_per_pixel_x, self.millimetres_per_pixel_y],
            dtype=float,
        )
        return values / scale

    def to_dict(self) -> dict[str, object]:
        return {
            "profile_id": self.profile_id,
            "canvas": {
                "pixel_width": self.pixel_width,
                "pixel_height": self.pixel_height,
                "physical_width_mm": self.physical_width_mm,
                "physical_height_mm": self.physical_height_mm,
            },
            "marker": {
                "width_mm": self.marker_width_mm,
                "radius_mm": self.marker_radius_mm,
                "width_pixels": self.marker_width_pixels,
            },
        }


# The active calibration keeps the raster aspect ratio while mapping the fixed
# 5 mm marker onto the 700 × 350 mm physical canvas.
WAYPOINT_V5_DIGITAL_CONTRACT = DrawingContract(
    profile_id="rainbow-marker-v2-digital-700x350",
    pixel_width=1024,
    pixel_height=512,
    physical_width_mm=700.0,
    physical_height_mm=350.0,
    marker_width_mm=5.0,
)

# Current paper execution contract: the same 2:1 digital canvas with the
# physical marker width requested for the paired rerun.
WAYPOINT_V5_DIGITAL_2MM_CONTRACT = DrawingContract(
    profile_id="rainbow-marker-v2-digital-700x350-marker-2mm",
    pixel_width=1024,
    pixel_height=512,
    physical_width_mm=700.0,
    physical_height_mm=350.0,
    marker_width_mm=2.0,
)
