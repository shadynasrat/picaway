"""Footprint-aware eraser path safety for localized drawing edits.

An eraser is not a marker with a wider render width.  Its swept footprint may
cross an edit-mask boundary into blank canvas, but it must not remove existing
ink outside that boundary.  This module filters eraser candidate paths against
that protected outside ink and reports any old ink that is physically
unreachable with the configured eraser footprint.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable

import cv2
import numpy as np
from scipy.spatial import cKDTree

from planning_core.Modules.Canvas.drawing_contract import DrawingContract
from planning_core.Modules.Canvas.fill_planner import Stroke, render_marker_strokes


@dataclass(frozen=True)
class SafeEraserPlan:
    """A protected eraser trajectory and its rendered diagnostics."""

    paths: tuple[Stroke, ...]
    coverage_mask: np.ndarray
    pass_count: np.ndarray
    residual_mask: np.ndarray
    protected_damage_mask: np.ndarray
    outside_edit_footprint_mask: np.ndarray
    safe_center_mask: np.ndarray
    metrics: dict[str, float | int | str]


def _order_safe_paths_for_travel(
    paths: tuple[Stroke, ...],
    contract: DrawingContract,
) -> tuple[tuple[Stroke, ...], int, int]:
    """Permute and orient complete safe strokes without changing geometry."""

    normalized = [path for path in paths if path]
    if len(normalized) < 2:
        return tuple(normalized), 0, 0

    endpoints_mm = np.asarray(
        [
            endpoint
            for path in normalized
            for endpoint in contract.pixel_to_mm(
                np.asarray((path[0], path[-1]), dtype=float)
            )
        ],
        dtype=float,
    )
    endpoint_tree = cKDTree(endpoints_mm)
    used_paths: set[int] = set()
    ordered: list[Stroke] = []
    path_indices: list[int] = []
    reversal_count = 0

    current_path = 0
    used_paths.add(current_path)
    ordered.append(normalized[current_path])
    path_indices.append(current_path)
    current_point = endpoints_mm[2 * current_path + 1]

    while len(ordered) < len(normalized):
        endpoint_count = len(endpoints_mm)
        query_count = min(endpoint_count, 16)
        selected: tuple[int, int] | None = None
        while True:
            distances, indices = endpoint_tree.query(current_point, k=query_count)
            candidates: list[tuple[float, int, int, int]] = []
            for distance, endpoint_index in zip(
                np.atleast_1d(distances), np.atleast_1d(indices), strict=True
            ):
                if not np.isfinite(distance):
                    continue
                flat_index = int(endpoint_index)
                path_index = flat_index // 2
                entry_endpoint = flat_index % 2
                if path_index in used_paths:
                    continue
                candidates.append(
                    (float(distance), flat_index, path_index, entry_endpoint)
                )
            if candidates:
                _, _, next_path, entry_endpoint = min(candidates)
                selected = (next_path, entry_endpoint)
                break
            if query_count == endpoint_count:
                break
            query_count = min(endpoint_count, query_count * 2)

        if selected is None:
            for next_path in range(len(normalized)):
                if next_path not in used_paths:
                    selected = (next_path, 0)
                    break
        if selected is None:
            break

        next_path, entry_endpoint = selected
        source = normalized[next_path]
        if entry_endpoint == 0:
            oriented = source
            exit_endpoint = 1
        else:
            oriented = tuple(reversed(source))
            reversal_count += 1
            exit_endpoint = 0
        used_paths.add(next_path)
        ordered.append(oriented)
        path_indices.append(next_path)
        current_point = endpoints_mm[2 * next_path + exit_endpoint]

    order_change_count = sum(
        index != path_index
        for index, path_index in enumerate(path_indices)
    )
    return tuple(ordered), order_change_count, reversal_count


def _as_mask(mask: np.ndarray, shape: tuple[int, int], name: str) -> np.ndarray:
    result = np.asarray(mask, dtype=bool)
    if result.shape != shape:
        raise ValueError(f"{name} has shape {result.shape}; expected {shape}")
    return result


def _densify_stroke(stroke: Stroke, step_pixels: float = 1.0) -> np.ndarray:
    points = np.asarray(stroke, dtype=float)
    if len(points) < 2:
        return points
    samples: list[np.ndarray] = []
    for first, second in zip(points, points[1:]):
        distance = float(np.linalg.norm(second - first))
        count = max(1, int(np.ceil(distance / step_pixels)))
        samples.extend(np.linspace(first, second, count, endpoint=False))
    samples.append(points[-1])
    return np.asarray(samples)


def clip_stroke_to_mask(stroke: Stroke, mask: np.ndarray) -> list[Stroke]:
    """Return contiguous subpaths whose densely sampled centers are in mask."""

    points = _densify_stroke(stroke)
    if len(points) < 2:
        return []
    height, width = mask.shape
    pixels = np.rint(points).astype(int)
    pixels[:, 0] = np.clip(pixels[:, 0], 0, width - 1)
    pixels[:, 1] = np.clip(pixels[:, 1], 0, height - 1)
    inside = mask[pixels[:, 1], pixels[:, 0]]
    paths: list[Stroke] = []
    start: int | None = None
    for index, selected in enumerate(inside):
        if selected and start is None:
            start = index
        if start is not None and (not selected or index == len(inside) - 1):
            stop = index + 1 if selected and index == len(inside) - 1 else index
            if stop - start >= 2:
                paths.append(
                    tuple((float(x), float(y)) for x, y in points[start:stop])
                )
            start = None
    return paths


def _protected_center_exclusion(
    protected_ink: np.ndarray,
    contract: DrawingContract,
    safety_margin_pixels: int,
) -> np.ndarray:
    radius_x = max(
        1,
        int(math.ceil(
            contract.marker_radius_mm / contract.millimetres_per_pixel_x
        )) + safety_margin_pixels,
    )
    radius_y = max(
        1,
        int(math.ceil(
            contract.marker_radius_mm / contract.millimetres_per_pixel_y
        )) + safety_margin_pixels,
    )
    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (2 * radius_x + 1, 2 * radius_y + 1),
    )
    return cv2.dilate(protected_ink.astype(np.uint8), kernel) > 0


def plan_safe_eraser_paths(
    candidate_paths: Iterable[Stroke],
    *,
    erase_target: np.ndarray,
    edit_mask: np.ndarray,
    protected_ink: np.ndarray,
    contract: DrawingContract,
    safety_margin_pixels: int = 1,
    travel_ordering_enabled: bool = True,
) -> SafeEraserPlan:
    """Clip eraser candidates to placements that preserve outside ink.

    ``erase_target`` is the old ink to remove inside ``edit_mask``.
    ``protected_ink`` is existing ink outside that mask.  Candidate centers are
    excluded from the protected ink dilated by the physical eraser radius, and
    each resulting path is rendered once more before acceptance.  The latter
    check makes protected-ink damage exactly zero despite raster rounding.
    """

    if safety_margin_pixels < 0:
        raise ValueError("safety_margin_pixels must not be negative")
    shape = contract.canvas_shape
    selected_region = _as_mask(edit_mask, shape, "edit_mask")
    target = _as_mask(erase_target, shape, "erase_target") & selected_region
    protected = _as_mask(protected_ink, shape, "protected_ink") & ~selected_region
    candidates = tuple(candidate_paths)

    exclusion = _protected_center_exclusion(
        protected,
        contract,
        safety_margin_pixels,
    )
    safe_centers = selected_region & ~exclusion
    clipped: list[Stroke] = []
    for stroke in candidates:
        clipped.extend(clip_stroke_to_mask(stroke, safe_centers))

    accepted: list[Stroke] = []
    rejected_for_protected_ink = 0
    for stroke in clipped:
        footprint, _ = render_marker_strokes(
            (stroke,),
            shape,
            contract.marker_width_pixels,
        )
        if np.logical_and(footprint, protected).any():
            rejected_for_protected_ink += 1
            continue
        accepted.append(stroke)

    safe_paths = tuple(accepted)
    if travel_ordering_enabled:
        safe_paths, route_order_change_count, route_reversal_count = (
            _order_safe_paths_for_travel(safe_paths, contract)
        )
    else:
        route_order_change_count = 0
        route_reversal_count = 0

    coverage, pass_count = render_marker_strokes(
        safe_paths,
        shape,
        contract.marker_width_pixels,
    )
    residual = target & ~coverage
    protected_damage = coverage & protected
    outside_edit = coverage & ~selected_region
    target_pixels = int(target.sum())
    erased_target_pixels = int(np.logical_and(target, coverage).sum())
    rendered_pixels = int(coverage.sum())
    protected_pixels = int(protected.sum())
    metrics: dict[str, float | int | str] = {
        "planner": "protected_footprint_eraser",
        "eraser_width_mm": float(contract.marker_width_mm),
        "candidate_path_count": len(candidates),
        "clipped_path_count": len(clipped),
        "rejected_protected_path_count": rejected_for_protected_ink,
        "path_count": len(safe_paths),
        "waypoint_count": sum(len(path) for path in safe_paths),
        "travel_ordering_enabled": int(travel_ordering_enabled),
        "route_order_change_count": route_order_change_count,
        "route_reversal_count": route_reversal_count,
        "erase_target_pixels": target_pixels,
        "erased_target_pixels": erased_target_pixels,
        "erase_target_coverage_ratio": erased_target_pixels / max(1, target_pixels),
        "boundary_residual_pixels": int(residual.sum()),
        "boundary_residual_ratio": int(residual.sum()) / max(1, target_pixels),
        "outside_edit_footprint_pixels": int(outside_edit.sum()),
        "outside_edit_footprint_ratio": int(outside_edit.sum()) / max(1, rendered_pixels),
        "protected_outside_ink_pixels": protected_pixels,
        "protected_outside_ink_damage_pixels": int(protected_damage.sum()),
        "protected_outside_ink_damage_ratio": int(protected_damage.sum())
        / max(1, protected_pixels),
        "safety_margin_pixels": safety_margin_pixels,
    }
    return SafeEraserPlan(
        paths=safe_paths,
        coverage_mask=coverage,
        pass_count=pass_count,
        residual_mask=residual,
        protected_damage_mask=protected_damage,
        outside_edit_footprint_mask=outside_edit,
        safe_center_mask=safe_centers,
        metrics=metrics,
    )
