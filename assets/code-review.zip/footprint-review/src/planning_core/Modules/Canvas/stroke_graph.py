"""Topology-aware path graph data structures for waypoint extraction."""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable


PointMm = tuple[float, float]


@dataclass(frozen=True)
class StrokeNode:
    node_id: str
    component_id: str
    x_mm: float
    y_mm: float
    kind: str
    incident_edges: tuple[str, ...]
    loop_edges: tuple[str, ...] = ()

    @property
    def degree(self) -> int:
        return len(self.incident_edges) + len(self.loop_edges)


@dataclass(frozen=True)
class StrokeEdge:
    edge_id: str
    component_id: str
    source_node_id: str
    target_node_id: str
    points_mm: tuple[PointMm, ...]
    source_path_id: str
    required: bool
    closed: bool

    @property
    def length_mm(self) -> float:
        total = 0.0
        for first, second in zip(self.points_mm[:-1], self.points_mm[1:]):
            total += math.hypot(second[0] - first[0], second[1] - first[1])
        return total


@dataclass(frozen=True)
class StrokeGraph:
    """Immutable graph artifact with stable ordering and JSON serialization."""

    nodes: tuple[StrokeNode, ...]
    edges: tuple[StrokeEdge, ...]
    component_ids: tuple[str, ...]

    def validate(self) -> None:
        node_ids = {node.node_id for node in self.nodes}
        edge_ids = {edge.edge_id for edge in self.edges}
        if len(node_ids) != len(self.nodes):
            raise ValueError("stroke graph contains duplicate node IDs")
        if len(edge_ids) != len(self.edges):
            raise ValueError("stroke graph contains duplicate edge IDs")
        if any(len(edge.points_mm) < 2 for edge in self.edges):
            raise ValueError("every stroke edge must contain at least two points")
        for edge in self.edges:
            if edge.source_node_id not in node_ids or edge.target_node_id not in node_ids:
                raise ValueError(f"edge {edge.edge_id} refers to an unknown node")
            if edge.closed and edge.source_node_id != edge.target_node_id:
                raise ValueError(f"closed edge {edge.edge_id} must return to its anchor")
        if set(self.component_ids) != {edge.component_id for edge in self.edges}:
            raise ValueError("component_ids do not match the edge components")

    def topology_counts(self) -> dict[str, int]:
        return {
            "components": len(self.component_ids),
            "nodes": len(self.nodes),
            "edges": len(self.edges),
            "endpoints": sum(node.kind == "endpoint" for node in self.nodes),
            "junctions": sum(node.kind == "junction" for node in self.nodes),
            "closed_loops": sum(edge.closed for edge in self.edges),
        }

    def to_dict(self) -> dict[str, object]:
        return {
            "units": "mm",
            "components": list(self.component_ids),
            "nodes": [
                {
                    "node_id": node.node_id,
                    "component_id": node.component_id,
                    "x_mm": node.x_mm,
                    "y_mm": node.y_mm,
                    "kind": node.kind,
                    "degree": node.degree,
                    "incident_edges": list(node.incident_edges),
                    "loop_edges": list(node.loop_edges),
                }
                for node in self.nodes
            ],
            "edges": [
                {
                    "edge_id": edge.edge_id,
                    "component_id": edge.component_id,
                    "source_node_id": edge.source_node_id,
                    "target_node_id": edge.target_node_id,
                    "source_path_id": edge.source_path_id,
                    "required": edge.required,
                    "closed": edge.closed,
                    "length_mm": edge.length_mm,
                    "points_mm": [list(point) for point in edge.points_mm],
                }
                for edge in self.edges
            ],
            "topology_counts": self.topology_counts(),
        }


def total_length_mm(edges: Iterable[StrokeEdge]) -> float:
    return float(sum(edge.length_mm for edge in edges))
