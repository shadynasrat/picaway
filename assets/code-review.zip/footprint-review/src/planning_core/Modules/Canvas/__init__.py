"""Minimal namespace for the preserved Footprint implementation."""
