"""Raw raster medial-graph extraction for waypoint extraction.

This module intentionally stops at a raw graph.  It removes fixed-width ink
from the representation by skeletonizing the binary mask and collapses degree-
two pixel chains into graph edges, but it does not decide whether a raster
crossing is a true junction.  That decision belongs to topology repair.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable

import numpy as np

from planning_core.Modules.Canvas.drawing_contract import DrawingContract
from planning_core.Modules.Canvas.stroke_graph import StrokeEdge, StrokeGraph, StrokeNode


Pixel = tuple[int, int]


@dataclass(frozen=True)
class CenterlineExtractionResult:
    """Raw skeleton and graph artifact from one binary ink mask."""

    skeleton: np.ndarray
    graph: StrokeGraph
    pipeline_version: str = "waypoint_v5_raw_medial_graph_v1"


def _neighbors(pixel: Pixel, skeleton: np.ndarray) -> list[Pixel]:
    y, x = pixel
    height, width = skeleton.shape
    result: list[Pixel] = []
    for delta_y in (-1, 0, 1):
        for delta_x in (-1, 0, 1):
            if delta_y == 0 and delta_x == 0:
                continue
            neighbor_y = y + delta_y
            neighbor_x = x + delta_x
            if (
                0 <= neighbor_y < height
                and 0 <= neighbor_x < width
                and skeleton[neighbor_y, neighbor_x]
            ):
                result.append((neighbor_y, neighbor_x))
    return sorted(result)


def _edge_key(first: Pixel, second: Pixel) -> tuple[Pixel, Pixel]:
    return tuple(sorted((first, second)))  # type: ignore[return-value]


def _zhang_suen(mask: np.ndarray) -> np.ndarray:
    """Deterministic dependency-free skeleton seed."""

    image = mask.astype(np.uint8).copy()
    if image.size == 0:
        return image.astype(bool)
    height, width = image.shape
    if height < 3 or width < 3:
        return image.astype(bool)

    while True:
        changed = False
        for iteration in (0, 1):
            padded = np.pad(image, 1, mode="constant")
            neighbors = [
                padded[0:height, 1 : width + 1],
                padded[0:height, 2 : width + 2],
                padded[1 : height + 1, 2 : width + 2],
                padded[2 : height + 2, 2 : width + 2],
                padded[2 : height + 2, 1 : width + 1],
                padded[2 : height + 2, 0:width],
                padded[1 : height + 1, 0:width],
                padded[0:height, 0:width],
            ]
            transitions = sum(
                ((first == 0) & (second == 1)).astype(np.uint8)
                for first, second in zip(neighbors, neighbors[1:] + neighbors[:1])
            )
            count = sum(neighbor for neighbor in neighbors)
            if iteration == 0:
                condition_1 = neighbors[0] * neighbors[2] * neighbors[4] == 0
                condition_2 = neighbors[2] * neighbors[4] * neighbors[6] == 0
            else:
                condition_1 = neighbors[0] * neighbors[2] * neighbors[6] == 0
                condition_2 = neighbors[0] * neighbors[4] * neighbors[6] == 0
            remove = (
                (image == 1)
                & (count >= 2)
                & (count <= 6)
                & (transitions == 1)
                & condition_1
                & condition_2
            )
            if np.any(remove):
                image[remove] = 0
                changed = True
        if not changed:
            break
    return image.astype(bool)


def _pixel_to_mm(pixel: Pixel, contract: DrawingContract) -> tuple[float, float]:
    y, x = pixel
    point = contract.pixel_to_mm([[float(x), float(y)]])[0]
    return (float(point[0]), float(point[1]))


def _pixel_components(
    pixels: list[Pixel],
    pixel_neighbors: dict[Pixel, list[Pixel]],
) -> list[set[Pixel]]:
    """Return deterministic 8-connected skeleton components."""

    remaining = set(pixels)
    components: list[set[Pixel]] = []
    while remaining:
        seed = min(remaining)
        remaining.remove(seed)
        component = {seed}
        stack = [seed]
        while stack:
            current = stack.pop()
            for neighbor in pixel_neighbors[current]:
                if neighbor in remaining:
                    remaining.remove(neighbor)
                    component.add(neighbor)
                    stack.append(neighbor)
        components.append(component)
    return sorted(components, key=lambda component: min(component))


def _junction_clusters(junction_pixels: set[Pixel]) -> list[set[Pixel]]:
    """Contract touching high-degree pixels into topological junction regions."""

    remaining = set(junction_pixels)
    clusters: list[set[Pixel]] = []
    while remaining:
        seed = min(remaining)
        remaining.remove(seed)
        cluster = {seed}
        stack = [seed]
        while stack:
            current = stack.pop()
            for neighbor in _neighbors_from_set(current, junction_pixels):
                if neighbor in remaining:
                    remaining.remove(neighbor)
                    cluster.add(neighbor)
                    stack.append(neighbor)
        clusters.append(cluster)
    return sorted(clusters, key=lambda cluster: min(cluster))


def _neighbors_from_set(pixel: Pixel, pixels: set[Pixel]) -> list[Pixel]:
    y, x = pixel
    return sorted(
        (y + delta_y, x + delta_x)
        for delta_y in (-1, 0, 1)
        for delta_x in (-1, 0, 1)
        if (delta_y != 0 or delta_x != 0)
        and (y + delta_y, x + delta_x) in pixels
    )


def _cluster_center(cluster: set[Pixel]) -> tuple[float, float]:
    array = np.asarray(sorted(cluster), dtype=float)
    return (float(array[:, 0].mean()), float(array[:, 1].mean()))


def _cluster_boundary(
    cluster: set[Pixel],
    pixel_neighbors: dict[Pixel, list[Pixel]],
) -> list[Pixel]:
    """Return skeleton pixels just outside a candidate junction cluster."""

    return sorted(
        {
            neighbor
            for pixel in cluster
            for neighbor in pixel_neighbors[pixel]
            if neighbor not in cluster
        }
    )


def _simplify_points(
    points: tuple[tuple[float, float], ...],
    tolerance_mm: float,
) -> tuple[tuple[float, float], ...]:
    """Reduce raster stair-step points with a deterministic Ramer-Douglas-Peucker pass."""

    if len(points) <= 2:
        return points

    first = np.asarray(points[0], dtype=float)
    last = np.asarray(points[-1], dtype=float)
    segment = last - first
    segment_length_squared = float(np.dot(segment, segment))
    maximum_distance = -1.0
    split_index = -1
    for index, point in enumerate(points[1:-1], start=1):
        candidate = np.asarray(point, dtype=float)
        if segment_length_squared == 0.0:
            distance = float(np.linalg.norm(candidate - first))
        else:
            projection = float(np.dot(candidate - first, segment) / segment_length_squared)
            projection = max(0.0, min(1.0, projection))
            closest = first + projection * segment
            distance = float(np.linalg.norm(candidate - closest))
        if distance > maximum_distance:
            maximum_distance = distance
            split_index = index

    if maximum_distance <= tolerance_mm or split_index < 0:
        return (points[0], points[-1])
    left = _simplify_points(points[: split_index + 1], tolerance_mm)
    right = _simplify_points(points[split_index:], tolerance_mm)
    return left[:-1] + right


def _component_ids(edges: Iterable[StrokeEdge]) -> dict[str, str]:
    ordered_edges = list(edges)
    parent = {edge.edge_id: edge.edge_id for edge in ordered_edges}

    def find(edge_id: str) -> str:
        while parent[edge_id] != edge_id:
            parent[edge_id] = parent[parent[edge_id]]
            edge_id = parent[edge_id]
        return edge_id

    def union(first: str, second: str) -> None:
        first_root = find(first)
        second_root = find(second)
        if first_root != second_root:
            parent[second_root] = first_root

    by_node: dict[str, str] = {}
    for edge in ordered_edges:
        for node_id in {edge.source_node_id, edge.target_node_id}:
            if node_id in by_node:
                union(by_node[node_id], edge.edge_id)
            else:
                by_node[node_id] = edge.edge_id
    groups: dict[str, list[str]] = {}
    for edge in ordered_edges:
        groups.setdefault(find(edge.edge_id), []).append(edge.edge_id)
    result: dict[str, str] = {}
    for index, group in enumerate(sorted(groups.values(), key=lambda values: min(values)), start=1):
        result.update({edge_id: f"component-{index:03d}" for edge_id in group})
    return result


def _build_graph(skeleton: np.ndarray, contract: DrawingContract) -> StrokeGraph:
    active_pixels = sorted(map(tuple, np.argwhere(skeleton)))
    if not active_pixels:
        return StrokeGraph((), (), ())

    pixel_neighbors = {pixel: _neighbors(pixel, skeleton) for pixel in active_pixels}
    endpoint_pixels = {
        pixel for pixel, neighbors in pixel_neighbors.items() if len(neighbors) == 1
    }
    junction_pixels = {
        pixel for pixel, neighbors in pixel_neighbors.items() if len(neighbors) >= 3
    }
    junction_clusters = _junction_clusters(junction_pixels)
    true_junction_clusters: list[set[Pixel]] = []
    pass_through_clusters: list[set[Pixel]] = []
    for cluster in junction_clusters:
        # An 8-connected one-pixel skeleton frequently creates a local
        # diagonal contact with degree 3 or 4 even though only two branches
        # continue through the region.  Only a cluster with three or more
        # outside branches is a topological junction; two-branch clusters are
        # contracted into a virtual pass-through edge below.
        if len(_cluster_boundary(cluster, pixel_neighbors)) >= 3:
            true_junction_clusters.append(cluster)
        else:
            pass_through_clusters.append(cluster)

    pass_through_pixels = {
        pixel for cluster in pass_through_clusters for pixel in cluster
    }
    route_pixels = set(active_pixels) - pass_through_pixels
    route_neighbors: dict[Pixel, set[Pixel]] = {
        pixel: {
            neighbor
            for neighbor in pixel_neighbors[pixel]
            if neighbor in route_pixels
        }
        for pixel in route_pixels
    }
    for cluster in pass_through_clusters:
        boundary = _cluster_boundary(cluster, pixel_neighbors)
        if len(boundary) == 2:
            first, second = boundary
            route_neighbors[first].add(second)
            route_neighbors[second].add(first)
    ordered_route_neighbors = {
        pixel: sorted(neighbors) for pixel, neighbors in route_neighbors.items()
    }

    node_specs: list[tuple[Pixel, str, set[Pixel]]] = [
        (pixel, "endpoint", {pixel}) for pixel in endpoint_pixels
    ]
    for cluster in true_junction_clusters:
        center = _cluster_center(cluster)
        representative = min(
            cluster,
            key=lambda pixel: (
                (pixel[0] - center[0]) ** 2 + (pixel[1] - center[1]) ** 2,
                pixel,
            ),
        )
        node_specs.append((representative, "junction", cluster))

    # A component with no endpoints or junctions is a closed loop.  Give each
    # such component one anchor so multiple disconnected loops are retained.
    for component in _pixel_components(
        sorted(route_pixels), ordered_route_neighbors
    ):
        if not any(
            pixel in endpoint_pixels
            or any(pixel in cluster for cluster in true_junction_clusters)
            for pixel in component
        ):
            anchor = min(component)
            node_specs.append((anchor, "loop_anchor", {anchor}))

    node_specs.sort(key=lambda spec: spec[0])
    node_id_by_pixel: dict[Pixel, str] = {}
    node_kind_by_id: dict[str, str] = {}
    node_center_by_id: dict[str, tuple[float, float]] = {}
    for index, (representative, kind, cluster) in enumerate(node_specs, start=1):
        node_id = f"node-{index:03d}"
        for pixel in cluster:
            node_id_by_pixel[pixel] = node_id
        node_kind_by_id[node_id] = kind
        node_center_by_id[node_id] = _cluster_center(cluster)
    node_pixels = set(node_id_by_pixel)
    visited_edges: set[tuple[Pixel, Pixel]] = set()
    preliminary_edges: list[StrokeEdge] = []
    next_edge = 1

    for start_pixel in sorted(node_pixels):
        for first_neighbor in ordered_route_neighbors[start_pixel]:
            if node_id_by_pixel.get(first_neighbor) == node_id_by_pixel.get(start_pixel):
                continue
            key = _edge_key(start_pixel, first_neighbor)
            if key in visited_edges:
                continue
            visited_edges.add(key)
            path = [start_pixel, first_neighbor]
            previous = start_pixel
            current = first_neighbor
            while current not in node_pixels:
                candidates = [
                    pixel
                    for pixel in ordered_route_neighbors[current]
                    if pixel != previous
                ]
                if not candidates:
                    break
                next_pixel = candidates[0]
                next_key = _edge_key(current, next_pixel)
                if next_key in visited_edges:
                    break
                visited_edges.add(next_key)
                path.append(next_pixel)
                previous, current = current, next_pixel
            if current not in node_pixels:
                continue
            source_node = node_id_by_pixel[start_pixel]
            target_node = node_id_by_pixel[current]
            points_mm = _simplify_points(
                tuple(_pixel_to_mm(pixel, contract) for pixel in path),
                tolerance_mm=min(0.25 * contract.marker_width_mm, 0.5),
            )
            if len(points_mm) >= 2:
                preliminary_edges.append(
                    StrokeEdge(
                        edge_id=f"raw-edge-{next_edge:04d}",
                        component_id="",
                        source_node_id=source_node,
                        target_node_id=target_node,
                        points_mm=points_mm,
                        source_path_id="raster-skeleton",
                        required=True,
                        closed=source_node == target_node,
                    )
                )
                next_edge += 1

    component_by_edge = _component_ids(preliminary_edges)
    edges = tuple(
        StrokeEdge(
            edge_id=edge.edge_id,
            component_id=component_by_edge[edge.edge_id],
            source_node_id=edge.source_node_id,
            target_node_id=edge.target_node_id,
            points_mm=edge.points_mm,
            source_path_id=edge.source_path_id,
            required=edge.required,
            closed=edge.closed,
        )
        for edge in preliminary_edges
    )
    incident: dict[str, list[str]] = {node_id: [] for node_id in node_id_by_pixel.values()}
    loop_nodes: set[str] = set()
    for edge in edges:
        incident[edge.source_node_id].append(edge.edge_id)
        if edge.target_node_id != edge.source_node_id:
            incident[edge.target_node_id].append(edge.edge_id)
        if edge.closed:
            loop_nodes.add(edge.source_node_id)

    node_component: dict[str, str] = {}
    for edge in edges:
        node_component.setdefault(edge.source_node_id, edge.component_id)
        node_component.setdefault(edge.target_node_id, edge.component_id)
    nodes = []
    for node_id in sorted(node_kind_by_id):
        edge_ids = tuple(incident[node_id])
        loop_edge_ids = tuple(
            edge.edge_id
            for edge in edges
            if edge.closed and edge.source_node_id == node_id
        )
        if node_id in loop_nodes:
            kind = "loop_anchor"
        elif node_kind_by_id.get(node_id) == "junction":
            kind = "junction"
        elif len(edge_ids) == 1:
            kind = "endpoint"
        elif len(edge_ids) >= 3:
            kind = "junction"
        else:
            kind = "pass_through"
        x_mm, y_mm = _pixel_to_mm(node_center_by_id[node_id], contract)
        nodes.append(
            StrokeNode(
                node_id=node_id,
                component_id=node_component.get(node_id, ""),
                x_mm=x_mm,
                y_mm=y_mm,
                kind=kind,
                incident_edges=edge_ids,
                loop_edges=loop_edge_ids,
            )
        )

    graph = StrokeGraph(tuple(nodes), edges, tuple(sorted(set(component_by_edge.values()))))
    graph.validate()
    return graph


def extract_centerline_graph(
    binary_ink_mask: np.ndarray,
    contract: DrawingContract,
) -> CenterlineExtractionResult:
    """Skeletonize a binary ink mask and return its raw topology graph."""

    mask = np.asarray(binary_ink_mask, dtype=bool)
    if mask.shape != contract.canvas_shape:
        raise ValueError(
            f"binary_ink_mask has shape {mask.shape}; expected {contract.canvas_shape}"
        )
    skeleton = _zhang_suen(mask)
    return CenterlineExtractionResult(skeleton=skeleton, graph=_build_graph(skeleton, contract))
