"""Small CPU runners; outputs are always written to a new directory."""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image
from . import DrawingContract, FootprintPolicy, plan_footprint
from planning_core.Modules.Canvas.eraser_planner import plan_safe_eraser_paths
from planning_core.Modules.Canvas.fill_planner import render_marker_strokes


def positive(value):
    value = float(value)
    if not np.isfinite(value) or value <= 0:
        raise argparse.ArgumentTypeError("must be finite and positive")
    return value


def raster(path):
    with Image.open(path) as image:
        # Transparent input is composited on white before thresholding.
        rgba = image.convert("RGBA")
        white = Image.new("RGBA", rgba.size, "white")
        return np.asarray(Image.alpha_composite(white, rgba).convert("L"))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def render(paths, contract):
    return render_marker_strokes(
        [np.asarray(p).tolist() for p in paths], contract.canvas_shape,
        (contract.marker_width_mm / contract.millimetres_per_pixel_x,
         contract.marker_width_mm / contract.millimetres_per_pixel_y),
    )[0]


def save_image(path, ink):
    Image.fromarray(np.where(ink, 0, 255).astype("uint8")).save(path)


def plan(mask, contract, method="proposed"):
    if method != "proposed":
        from .benchmark.baselines import PLANNERS
        paths = PLANNERS[method](mask, contract) if mask.any() else ()
        return tuple(np.asarray(p) for p in paths), {"status": "planned" if mask.any() else "empty_target", "method": method}

    if not mask.any():
        return (), {"status": "empty_target", "metrics": {}}
    result = plan_footprint(mask, contract=contract, policy=FootprintPolicy())
    return result.paths, {"status": result.status, "metrics": result.metrics, "audit": result.audit}


def run_plan(args):
    source = args.image if args.command == "draw" else args.parent
    image = raster(source)
    contract = DrawingContract("footprint-cli", image.shape[1], image.shape[0],
                               args.canvas_mm[0], args.canvas_mm[1], args.width_mm)
    if args.command == "edit":
        mask, updated = raster(args.mask), raster(args.updated)
        if mask.shape != image.shape or updated.shape != image.shape:
            raise ValueError("parent, mask and updated image must have identical dimensions")
    # Refuse to overwrite saved plans or partially reuse a prior run.
    args.out.mkdir(parents=True, exist_ok=False)
    output = {"schema_version": "1.0", "planner": args.method,
              "coordinate_units": "mm", "origin": "top-left", "y_direction": "down",
              "canvas_mm": args.canvas_mm, "raster_px": [image.shape[1], image.shape[0]],
              "marker_mm": args.width_mm, "policy": asdict(FootprintPolicy()) if args.method == "proposed" else {"baseline": args.method, "configuration": "preserved paper adapter defaults"},
              "coverage_note": "Coverage is sampled, not continuous-area certification."}
    if args.command == "draw":
        target = image < 128
        paths, details = plan(target, contract, args.method)
        output.update(input_sha256=digest(source), ink_threshold=128,
                      paths_mm=[contract.pixel_to_mm(p).tolist() for p in paths], details=details)
        save_image(args.out / "preview.png", render(paths, contract))
    else:
        parent, region, target = image < 180, mask >= 128, updated < 180
        eraser = DrawingContract("footprint-eraser", image.shape[1], image.shape[0],
                                *args.canvas_mm, args.eraser_mm or args.width_mm)
        proposals, erase_details = plan(parent & region, eraser, args.method)
        safe = plan_safe_eraser_paths([np.asarray(p).tolist() for p in proposals], erase_target=parent & region,
                                     edit_mask=region, protected_ink=parent & ~region,
                                     contract=eraser, travel_ordering_enabled=True)
        paths, draw_details = plan(target & region, contract, args.method)
        output.update(eraser_mm=eraser.marker_width_mm, ink_threshold=180, mask_threshold=128,
                      input_sha256={k: digest(getattr(args, k)) for k in ("parent", "mask", "updated")},
                      erase_paths_mm=[eraser.pixel_to_mm(np.asarray(p)).tolist() for p in safe.paths],
                      draw_paths_mm=[contract.pixel_to_mm(p).tolist() for p in paths],
                      details={"erase_proposal": erase_details, "clipping": safe.metrics, "draw": draw_details})
        save_image(args.out / "preview.png", (parent & ~safe.coverage_mask) | render(paths, contract))
        save_image(args.out / "erase-preview.png", safe.coverage_mask)
    (args.out / "paths.json").write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")
    print(args.out / "paths.json")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("draw", "edit"):
        cmd = sub.add_parser(name)
        if name == "draw":
            cmd.add_argument("image", type=Path)
        else:
            for field in ("parent", "mask", "updated"):
                cmd.add_argument("--" + field, type=Path, required=True)
            cmd.add_argument("--eraser-mm", type=positive)
        cmd.add_argument("--method", choices=["proposed", "legacy_picaso", "centerline_tracing", "contour_tracing", "coverage_planning", "naive_centerline_coverage"], default="proposed")
        cmd.add_argument("--width-mm", type=positive, default=2)
        cmd.add_argument("--canvas-mm", type=positive, nargs=2, default=[700., 350.], metavar=("WIDTH", "HEIGHT"))
        cmd.add_argument("--out", type=Path, required=True)
    rep = sub.add_parser("reproduce", help="aggregate saved results without planning")
    rep.add_argument("--data", type=Path, required=True)
    rep.add_argument("--out", type=Path, required=True)
    score = sub.add_parser("rescore", help="re-evaluate one saved paper trajectory (benchmark extra required)")
    score.add_argument("--data", type=Path, required=True)
    score.add_argument("--task", choices=["drawing", "editing"], required=True)
    score.add_argument("--id", required=True)
    score.add_argument("--method", default="proposed")
    score.add_argument("--width-mm", type=int, choices=[1,2,3,4,5], default=2)
    score.add_argument("--out", type=Path, required=True)
    dl = sub.add_parser("download", help="download selected checksum-verified dataset bundles")
    dl.add_argument("--repo", required=True)
    dl.add_argument("--revision", required=True)
    dl.add_argument("--bundle", nargs="+", default=["results"])
    dl.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.command == "reproduce":
            from .reproduce import reproduce
            reproduce(args.data, args.out)
        elif args.command == "rescore":
            from .benchmark.rescore import rescore
            rescore(args.data, args.task, args.id, args.method, args.width_mm, args.out)
        elif args.command == "download":
            from .download import download
            download(args.repo, args.revision, args.bundle, args.out)
        else:
            run_plan(args)
    except (ValueError, OSError) as exc:
        parser.exit(2, f"footprint: {exc}\n")


if __name__ == "__main__":
    main()
