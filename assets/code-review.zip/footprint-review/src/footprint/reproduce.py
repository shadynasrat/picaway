"""Reproduce paper tables from saved metrics, without importing a planner."""
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

METHODS = ["proposed", "coverage_planning", "naive_centerline_coverage",
           "legacy_picaso", "centerline_tracing", "contour_tracing"]
LABELS = ["Proposed", "Coverage Planning", "Naive Union", "PICaSo", "Centerline", "Contour"]


def load_cells(path, count):
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    lookup = {}
    for row in rows:
        key = (row["id"], row["method"], row["width_mm"])
        if key in lookup:
            raise ValueError(f"duplicate cell in {path.name}: {key}")
        if row["status"] != "success":
            raise ValueError(f"unsuccessful cell in {path.name}: {key}")
        lookup[key] = row
    ids = {key[0] for key in lookup}
    expected = {(identifier, method, width) for identifier in ids for method in METHODS for width in (1, 2, 3, 4, 5)}
    if len(ids) != count or set(lookup) != expected:
        raise ValueError(f"{path.name} does not contain the complete {count} × 6 × 5 design")
    return lookup, sorted(ids)


def reproduce(data, out):
    data, out = Path(data), Path(out)
    manifest = json.loads((data / "manifest.json").read_text())
    for name in ("drawing-results.jsonl", "editing-results.jsonl", "expected-tables.json"):
        digest = hashlib.sha256((data / name).read_bytes()).hexdigest()
        if digest != manifest["sha256"][name]:
            raise ValueError(f"checksum mismatch: {name}")
    drawing, dids = load_cells(data / "drawing-results.jsonl", 416)
    editing, eids = load_cells(data / "editing-results.jsonl", 140)
    tables = {"drawing": {}, "editing": {}}
    for method, label in zip(METHODS, LABELS):
        rows = [drawing[i, method, w] for i in dids for w in (1, 2, 3, 4, 5)]
        vals = [np.mean([r["metrics"][k] for r in rows]) for k in ("f1", "recall", "unwanted_per_target")]
        vals += [np.mean([r["motion"][k] for r in rows]) / scale for k, scale in (("pen_down_mm", 1000), ("pen_up_mm", 1000), ("touch_downs", 1))]
        tables["drawing"][label] = [f"{x:.{precision}f}" for x, precision in zip(vals, (4,4,4,2,2,2))]
        # Average widths within each image first; undefined removal is omitted.
        image_metrics = defaultdict(list)
        for identifier in eids:
            rows = [editing[identifier, method, w] for w in (1,2,3,4,5)]
            for name in ("obsolete_removal_fraction", "protected_erased_mm2", "local_f1", "f1", "new_ink_outside_mask_mm2"):
                values = [r["metrics"][name] for r in rows if r["metrics"][name] is not None]
                if values:
                    image_metrics[name].append(float(np.mean(values)))
            image_metrics["erase_distance_m"].append(float(np.mean([r["erase_motion"]["pen_down_mm"] for r in rows])) / 1000)
        vals = [100*np.mean(image_metrics["obsolete_removal_fraction"]),
                np.mean(image_metrics["protected_erased_mm2"]), np.mean(image_metrics["local_f1"]),
                np.mean(image_metrics["f1"]), np.mean(image_metrics["new_ink_outside_mask_mm2"]),
                np.percentile(image_metrics["new_ink_outside_mask_mm2"], 95), np.mean(image_metrics["erase_distance_m"])]
        tables["editing"][label] = [f"{x:.{precision}f}" for x, precision in zip(vals, (2,3,4,4,3,3,2))]
    expected = json.loads((data / "expected-tables.json").read_text())
    matches = tables == expected
    out.mkdir(parents=True, exist_ok=False)
    (out / "tables.json").write_text(json.dumps(tables, indent=2) + "\n")
    (out / "verification.json").write_text(json.dumps({"matches_paper_tables": matches, "drawing_cells": len(drawing), "editing_cells": len(editing)}, indent=2) + "\n")
    if not matches:
        raise ValueError(f"table mismatch; inspect {out / 'tables.json'}")
    print(f"Verified all paper table values from 12,480 drawing and 4,200 editing cells: {out}")
