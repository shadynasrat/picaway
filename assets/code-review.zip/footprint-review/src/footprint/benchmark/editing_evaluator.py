"""Research editing judge: polygonal circular footprints and persistent Boolean state.

Coordinates are millimetres. Disk approximation is numerical, not certification.
No planner imports. No footprint is clipped to the edit region or canvas.
"""
from shapely.errors import GEOSException
from dataclasses import dataclass
import numpy as np
from shapely.geometry import GeometryCollection, Point, LineString, box
from shapely.ops import unary_union


def raster_region(mask, scale=(1., 1.)):
    """Integer-centred pixel squares, physical extent/count scale."""
    a=np.asarray(mask)
    if a.ndim!=2 or a.dtype!=np.bool_: raise ValueError('Expected a 2D boolean mask')
    sx,sy=_scale(scale)
    return unary_union([box((x-.5)*sx,(y-.5)*sy,(x+.5)*sx,(y+.5)*sy)
                        for y,x in zip(*np.nonzero(a))])


def _scale(scale):
    a=np.asarray(scale,float)
    if a.shape!=(2,) or not np.isfinite(a).all() or np.any(a<=0): raise ValueError('Invalid scale')
    return a


def footprint(paths_mm, width_mm, resolution=128):
    if not np.isfinite(width_mm) or width_mm<=0: raise ValueError('Invalid tool diameter')
    if isinstance(resolution,bool) or not isinstance(resolution,int) or resolution<8: raise ValueError('Invalid resolution')
    parts=[]
    for path in paths_mm:
        p=np.asarray(path,float)
        if p.ndim!=2 or p.shape[1]!=2 or not len(p) or not np.isfinite(p).all(): raise ValueError('Invalid path')
        g=Point(p[0]) if len(p)==1 or np.all(p==p[0]) else LineString(p)
        parts.append(g.buffer(width_mm/2,quad_segs=resolution,cap_style='round',join_style='round'))
    return unary_union(parts)


OVERLAY_FALLBACKS = []

def persistent_missing(reference, before, eraser, drawing, current):
    """Equivalent staged set subtraction if GEOS fails on the final union."""
    try:
        return reference.difference(current).area
    except GEOSException:
        previously_missing = reference.difference(before)
        newly_removed = reference.intersection(before).intersection(eraser)
        value = previously_missing.union(newly_removed).difference(drawing).area
        OVERLAY_FALLBACKS.append({'operation':'persistent_missing_staged_set_identity','result':value})
        return value

def _valid(g):
    if not g.is_valid or (not g.is_empty and not np.isfinite(g.bounds).all()): raise ValueError('Invalid region')
    return g


def ratio(a,b):
    return float(a/b) if b>0 else None


@dataclass
class EditingJudge:
    initial: object
    persistent_protected: object
    canvas: object
    resolution: int=128

    def __post_init__(self):
        self.current=_valid(self.initial)
        self.reference=_valid(self.persistent_protected).intersection(self.initial)
        _valid(self.canvas)
        self.ever_erased_reference=GeometryCollection()
        self.step_count=0

    def step(self, desired, edit_region, protected, erase_paths_mm=(), eraser_width_mm=1.,
             draw_paths_mm=(), marker_width_mm=1.):
        """Protected is an explicit reference; denominator uses its currently present ink.

        Persistent protected region must denote content intended unchanged throughout
        the sequence. Historical erase damage remains recorded even after redraw.
        """
        for g in (desired,edit_region,protected): _valid(g)
        before=self.current
        obsolete=before.intersection(edit_region).difference(desired)
        protected_before=before.intersection(protected)
        eraser=footprint(erase_paths_mm,eraser_width_mm,self.resolution)
        drawing=footprint(draw_paths_mm,marker_width_mm,self.resolution)
        removed=obsolete.intersection(eraser)
        damage=protected_before.intersection(eraser)
        self.ever_erased_reference=self.ever_erased_reference.union(before.intersection(self.reference).intersection(eraser))
        after_erase=before.difference(eraser)
        self.current=after_erase.union(drawing)
        self.step_count+=1
        intersection=self.current.intersection(desired).area
        target=desired.area; ink=self.current.area
        unwanted=self.current.difference(desired).area
        return {'step':self.step_count,'obsolete_before_mm2':obsolete.area,
            'obsolete_removed_mm2':removed.area,'obsolete_removal_fraction':ratio(removed.area,obsolete.area),
            'protected_before_mm2':protected_before.area,'protected_erased_mm2':damage.area,
            'protected_damage_fraction':ratio(damage.area,protected_before.area),
            'final_ink_mm2':ink,'target_mm2':target,'intersection_mm2':intersection,
            'f1':ratio(2*intersection,target+ink),'coverage':ratio(intersection,target),
            'precision':ratio(intersection,ink),'unwanted_mm2':unwanted,
            'unwanted_per_target':ratio(unwanted,target),
            'off_canvas_ink_mm2':self.current.difference(self.canvas).area,
            'eraser_off_canvas_mm2':eraser.difference(self.canvas).area,
            'cumulative_protected_erased_mm2':self.ever_erased_reference.area,
            'cumulative_protected_damage_fraction':ratio(self.ever_erased_reference.area,self.reference.area),
            'persistent_protected_missing_mm2':persistent_missing(self.reference,before,eraser,drawing,self.current)}


def evaluate_sequence(initial, persistent_protected, canvas, steps, factors=(64,128,256,512), tolerance=.001):
    """Replay actual state at increasing circle resolution; keep per-step flags.

    Factors are polygon segments per quadrant, NOT drawing scanline factors.
    This is a separate research evaluator policy, not drawing contract 1.0.
    """
    if len(factors)<2 or any(b<=a for a,b in zip(factors,factors[1:])): raise ValueError('Need increasing factors')
    if not np.isfinite(tolerance) or tolerance<=0: raise ValueError('Invalid tolerance')
    steps=list(steps)
    if not steps: raise ValueError('Empty sequence')
    samples=[]; keys=('f1','coverage','precision','unwanted_per_target','obsolete_removal_fraction',
                     'protected_damage_fraction','cumulative_protected_damage_fraction')
    for factor in factors:
        judge=EditingJudge(initial,persistent_protected,canvas,factor)
        rows=[judge.step(**step) for step in steps];samples.append({'resolution':factor,'rows':rows})
        if len(samples)>1:
            deltas=[]
            for old,new in zip(samples[-2]['rows'],rows):
                changes=[abs(old[k]-new[k]) if old[k] is not None and new[k] is not None else (0. if old[k] is new[k] else float('inf')) for k in keys]
                deltas.append(max(changes))
            if max(deltas)<=tolerance: break
    return {'schema':'editing-polygon-judge-v1','rows':rows,'samples':samples,'step_convergence_deltas':deltas,
            'numerical_flags':[d>tolerance for d in deltas],
            'undefined_ratio_count':sum(row[k] is None for row in rows for k in keys),
            'limitation':'Polygon approximation and sensitivity checks are not area certification or physical validation.'}
