"""Disk-swept paths sampled directly in physical units; no image drawing library.

Pixels denote closed squares centered on integer coordinates. Samples retain
fractional occupancy. Geometry is a disk swept over each pen-down segment;
separate strokes are not connected. Sampling is numerical, not certification.
"""
import math
import numpy as np
from numba import njit


@njit(cache=True, nogil=True)
def _paint(segments, radius, sx, sy, factor, phase, x0, y0, width, height):
    ink = np.zeros((height*factor, width*factor), np.uint8)
    hx, hy = sx/factor, sy/factor
    ox, oy = x0*sx, y0*sy
    for k in range(len(segments)):
        ax,ay,bx,by = segments[k]
        dx,dy=bx-ax,by-ay
        l2=dx*dx+dy*dy
        length=math.sqrt(l2)
        j0=max(0,math.ceil((min(ay,by)-radius-oy)/hy-phase))
        j1=min(ink.shape[0]-1,math.floor((max(ay,by)+radius-oy)/hy-phase))
        for j in range(j0,j1+1):
            y=oy+(j+phase)*hy
            lo,hi=math.inf,-math.inf
            for ex,ey in ((ax,ay),(bx,by)):
                rr=radius*radius-(y-ey)*(y-ey)
                if rr>=0:
                    half=math.sqrt(rr)
                    lo=min(lo,ex-half);hi=max(hi,ex+half)
            # Intersection of the oriented segment rectangle with this scanline.
            if l2>0:
                left,right=-math.inf,math.inf
                c=dy*(y-ay)
                if dx!=0:
                    u,v=ax-c/dx,ax+(l2-c)/dx
                    left=max(left,min(u,v));right=min(right,max(u,v))
                elif c<0 or c>l2:
                    right=-math.inf
                c=dx*(y-ay)
                if dy!=0:
                    u,v=ax+(c-radius*length)/dy,ax+(c+radius*length)/dy
                    left=max(left,min(u,v));right=min(right,max(u,v))
                elif abs(c)>radius*length:
                    right=-math.inf
                if left<=right:
                    lo=min(lo,left);hi=max(hi,right)
            if lo<=hi:
                i0=max(0,math.ceil((lo-ox)/hx-phase))
                i1=min(ink.shape[1]-1,math.floor((hi-ox)/hx-phase))
                for i in range(i0,i1+1): ink[j,i]=1
    return ink


@njit(cache=True,nogil=True)
def _count(ink,target,factor,padx,pady):
    painted=0;intersection=0;inside=0
    for j in range(ink.shape[0]):
        ty=j//factor-pady
        for i in range(ink.shape[1]):
            if ink[j,i]:
                painted+=1
                tx=i//factor-padx
                if 0<=ty<target.shape[0] and 0<=tx<target.shape[1]:
                    inside+=1
                    if target[ty,tx]:intersection+=1
    return painted,intersection,inside


def prepare_segments(paths, scale=(1.,1.)):
    pieces=[]
    for path in paths:
        p=np.asarray(path,dtype=float)
        if p.size==0: continue
        if p.ndim!=2 or p.shape[1]!=2 or not np.isfinite(p).all():
            raise ValueError('Paths must be finite Nx2 arrays')
        p=p*np.asarray(scale)
        if len(p)==1: pieces.append(np.concatenate((p,p),axis=1))
        else: pieces.append(np.concatenate((p[:-1],p[1:]),axis=1))
    return np.concatenate(pieces) if pieces else np.empty((0,4),float)


def evaluate(target,paths,width_mm,scale=(1.,1.),factor=8,phase=.5):
    target=np.asarray(target,dtype=np.bool_)
    if target.ndim!=2 or not target.any(): raise ValueError('Positive target required')
    sx,sy=map(float,scale)
    if not all(np.isfinite(v) and v>0 for v in (sx,sy,width_mm)):raise ValueError('Positive finite dimensions required')
    if not isinstance(factor,int) or factor<1 or not 0<phase<1:raise ValueError('Invalid sampling configuration')
    seg=prepare_segments(paths,scale)
    r=width_mm/2;h,w=target.shape
    # Whole-pixel padding preserves pixel-cell alignment and includes ALL path ink.
    minx=min(-.5,float(seg[:,[0,2]].min()/sx-r/sx) if len(seg) else -.5)
    miny=min(-.5,float(seg[:,[1,3]].min()/sy-r/sy) if len(seg) else -.5)
    maxx=max(w-.5,float(seg[:,[0,2]].max()/sx+r/sx) if len(seg) else w-.5)
    maxy=max(h-.5,float(seg[:,[1,3]].max()/sy+r/sy) if len(seg) else h-.5)
    padx=max(0,math.ceil(-.5-minx));pady=max(0,math.ceil(-.5-miny))
    ew=w+padx+max(0,math.ceil(maxx-(w-.5)))
    eh=h+pady+max(0,math.ceil(maxy-(h-.5)))
    if ew*eh*factor*factor>600_000_000:raise ValueError('Sampling domain exceeds 600M cells; retain as explicit audit failure')
    ink=_paint(seg,r,sx,sy,factor,phase,-.5-padx,-.5-pady,ew,eh)
    painted,tp,inside=_count(ink,target,factor,padx,pady)
    area=sx*sy/(factor*factor);ta=float(target.sum())*sx*sy
    covered=tp*area;pa=painted*area
    return dict(factor=factor,phase=phase,target_area_mm2=ta,painted_area_mm2=pa,
                missing_area_mm2=ta-covered,unwanted_area_mm2=pa-covered,off_canvas_area_mm2=(painted-inside)*area,
                recall=covered/ta,precision=covered/pa if pa else 0.,f1=2*covered/(ta+pa),
                iou=covered/(ta+pa-covered),unwanted_per_target=(pa-covered)/ta)


@njit(cache=True,nogil=True)
def _interval(ax,ay,bx,by,r,y):
    dx,dy=bx-ax,by-ay;l2=dx*dx+dy*dy
    lo,hi=math.inf,-math.inf
    for ex,ey in ((ax,ay),(bx,by)):
        rr=r*r-(y-ey)*(y-ey)
        if rr>=0:
            half=math.sqrt(rr);lo=min(lo,ex-half);hi=max(hi,ex+half)
    if l2>0:
        left,right=-math.inf,math.inf;c=dy*(y-ay)
        if dx!=0:
            u,v=ax-c/dx,ax+(l2-c)/dx
            left=max(left,min(u,v));right=min(right,max(u,v))
        elif c<0 or c>l2:right=-math.inf
        c=dx*(y-ay);radius_length=r*math.sqrt(l2)
        if dy!=0:
            u,v=ax+(c-radius_length)/dy,ax+(c+radius_length)/dy
            left=max(left,min(u,v));right=min(right,max(u,v))
        elif abs(c)>radius_length:right=-math.inf
        if left<=right:lo=min(lo,left);hi=max(hi,right)
    return lo,hi


@njit(cache=True,nogil=True)
def _primitive(prefix,ty,x,sx):
    # Integral of the target row from its left boundary to x, in millimetres.
    z=min(max(x/sx+.5,0.),prefix.shape[1]-1.)
    i=int(math.floor(z))
    if i>=prefix.shape[1]-1:return prefix[ty,-1]*sx
    return (prefix[ty,i]+(z-i)*(prefix[ty,i+1]-prefix[ty,i]))*sx


@njit(cache=True,nogil=True)
def _integrate(segments,r,sx,sy,factor,phase,target):
    h,w=target.shape
    low=-.5;high=h-.5
    for a in segments:
        low=min(low,(min(a[1],a[3])-r)/sy)
        high=max(high,(max(a[1],a[3])+r)/sy)
    pad=max(0,math.ceil(-.5-low));end=h+max(0,math.ceil(high-(h-.5)))
    ny=(end+pad)*factor;origin=(-.5-pad)*sy;step=sy/factor
    counts=np.zeros(ny,np.int64)
    for a in segments:
        j0=max(0,math.ceil((min(a[1],a[3])-r-origin)/step-phase))
        j1=min(ny-1,math.floor((max(a[1],a[3])+r-origin)/step-phase))
        for j in range(j0,j1+1):counts[j]+=1
    offsets=np.empty(ny+1,np.int64);offsets[0]=0
    for j in range(ny):offsets[j+1]=offsets[j]+counts[j]
    left=np.empty(offsets[-1]);right=np.empty(offsets[-1]);cursor=offsets[:-1].copy()
    for a in segments:
        j0=max(0,math.ceil((min(a[1],a[3])-r-origin)/step-phase))
        j1=min(ny-1,math.floor((max(a[1],a[3])+r-origin)/step-phase))
        for j in range(j0,j1+1):
            lo,hi=_interval(a[0],a[1],a[2],a[3],r,origin+(j+phase)*step)
            k=cursor[j];left[k]=lo;right[k]=hi;cursor[j]+=1
    prefix=np.zeros((h,w+1),np.int64)
    for j in range(h):
        for i in range(w):prefix[j,i+1]=prefix[j,i]+int(target[j,i])
    painted=0.;covered=0.;inside=0.
    for j in range(ny):
        start,stop=offsets[j],offsets[j+1]
        if start==stop:continue
        order=np.argsort(left[start:stop])
        lo,hi=math.inf,-math.inf
        ty=j//factor-pad
        for n in range(len(order)+1):
            if n<len(order):
                k=start+order[n];a,b=left[k],right[k]
            else:a,b=math.inf,-math.inf
            if a>hi or n==len(order):
                if lo<=hi:
                    painted+=hi-lo
                    if 0<=ty<h:
                        covered+=_primitive(prefix,ty,hi,sx)-_primitive(prefix,ty,lo,sx)
                        inside+=max(0.,min(hi,(w-.5)*sx)-max(lo,-.5*sx))
                lo,hi=a,b
            else:hi=max(hi,b)
    return painted*step,covered*step,inside*step


# Retain the direct point sampler for independent calibration of the scanline path.
evaluate_point_grid=evaluate


def evaluate(target,paths,width_mm,scale=(1.,1.),factor=32,phase=.5):
    """Exact horizontal capsule intervals, numerical vertical midpoint integration."""
    target=np.asarray(target,dtype=np.bool_)
    if target.ndim!=2 or not target.any():raise ValueError('Positive target required')
    sx,sy=map(float,scale)
    if not all(np.isfinite(v) and v>0 for v in (sx,sy,width_mm)):raise ValueError('Positive finite dimensions required')
    if not isinstance(factor,int) or factor<1 or not 0<phase<1:raise ValueError('Invalid quadrature')
    segments=prepare_segments(paths,scale)
    pa,tp,inside=_integrate(segments,width_mm/2,sx,sy,factor,phase,target)
    ta=float(target.sum())*sx*sy
    return dict(factor=factor,phase=phase,target_area_mm2=ta,painted_area_mm2=pa,
                missing_area_mm2=ta-tp,unwanted_area_mm2=pa-tp,off_canvas_area_mm2=pa-inside,
                recall=tp/ta,precision=tp/pa if pa else 0.,f1=2*tp/(ta+pa),
                iou=tp/(ta+pa-tp),unwanted_per_target=(pa-tp)/ta)
