"""Rescore one published saved trajectory using the paper's numerical evaluators."""
import gzip
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image


def checked(data, manifest, relative):
    root = Path(data).resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError("dataset path escapes its root")
    content = path.read_bytes()
    if hashlib.sha256(content).hexdigest() != manifest['files'][relative]['sha256']:
        raise ValueError('checksum mismatch: ' + relative)
    return content


def drawing_score(target, paths, width):
    from .drawing_evaluator import evaluate
    samples = []
    for factor in (64, 128, 256, 512):
        samples.append(evaluate(target, paths, width, (700/1024, 350/512), factor=factor, phase=.5))
        if len(samples) >= 2:
            delta = max(abs(samples[-1][k]-samples[-2][k]) for k in ('f1','precision','recall'))
            if delta <= .001:
                break
    metrics = dict(samples[-1])
    metrics['unwanted_fraction_of_ink'] = metrics['unwanted_area_mm2']/metrics['painted_area_mm2'] if metrics['painted_area_mm2'] else None
    return {'metrics': metrics, 'samples': samples, 'convergence_delta': delta, 'numerical_flag': delta > .001}


def editing_score(parent, mask, target, paths, width):
    from shapely.geometry import box
    from shapely.ops import unary_union
    from . import editing_evaluator as ev
    scale = 700/1024
    def region(mask):
        parts = []
        for y, row in enumerate(mask):
            edges = np.diff(np.r_[False,row,False].astype(int))
            parts.extend(box((a-.5)*scale,(y-.5)*scale,(b-.5)*scale,(y+.5)*scale)
                         for a,b in zip(np.where(edges==1)[0],np.where(edges==-1)[0]))
        return unary_union(parts)
    ev.OVERLAY_FALLBACKS.clear()
    edit = region(mask)
    desired = region((parent & ~mask) | (target & mask))
    canvas = box(-.5*scale,-.5*scale,1023.5*scale,511.5*scale)
    samples = []
    keys = ('f1','coverage','precision','unwanted_per_target','obsolete_removal_fraction','protected_damage_fraction','local_f1')
    for resolution in (64,128,256,512):
        initial = ev.footprint(paths['parent'],width,resolution)
        protected = initial.difference(edit)
        judge = ev.EditingJudge(initial,protected,canvas,resolution)
        metrics = judge.step(desired,edit,protected,paths['erase'],width,paths['draw'],width)
        eraser = ev.footprint(paths['erase'],width,resolution)
        drawing = ev.footprint(paths['draw'],width,resolution)
        after = initial.difference(eraser)
        local, lt = judge.current.intersection(edit), desired.intersection(edit)
        metrics.update(local_f1=2*local.intersection(lt).area/(local.area+lt.area) if local.area+lt.area else None,
                       marker_contact_outside_mask_mm2=drawing.difference(edit).area,
                       new_ink_outside_mask_mm2=drawing.difference(edit).difference(after).area)
        samples.append({'resolution':resolution,'metrics':metrics})
        if len(samples) > 1:
            old = samples[-2]['metrics']
            changes = [abs(metrics[k]-old[k]) if metrics[k] is not None and old[k] is not None else (0 if metrics[k] is old[k] else float('inf')) for k in keys]
            delta = max(changes)
            area_delta = abs(metrics['protected_erased_mm2']-old['protected_erased_mm2'])
            if delta <= .001 and area_delta <= .01:
                break
    return {'metrics':metrics,'samples':samples,'convergence_delta':delta,
            'damage_area_resolution_change_mm2':area_delta,
            'numerical_flag':delta > .001 or area_delta > .01,
            'overlay_fallbacks':list(ev.OVERLAY_FALLBACKS)}


def rescore(data, task, identifier, method, width, out):
    data, out = Path(data), Path(out)
    if out.exists():
        raise ValueError('output directory already exists')
    manifest = json.loads((data/'manifest.json').read_text())
    rows = [json.loads(x) for x in checked(data,manifest,f'{task}/inputs.jsonl').splitlines()]
    row = next((r for r in rows if r['id']==identifier),None)
    if row is None:
        raise ValueError('unknown input ID')
    relative = f'{task}/trajectories/{method}/{width:g}mm/{identifier}.json.gz'
    if relative not in manifest['files']:
        raise ValueError('unknown saved trajectory')
    paths = json.loads(gzip.decompress(checked(data,manifest,relative)))
    if (paths['id'], paths['method'], paths['width_mm']) != (identifier, method, width):
        raise ValueError('trajectory identity mismatch')
    def raster(relative):
        from io import BytesIO
        with Image.open(BytesIO(checked(data,manifest,relative))) as im:
            if im.size != (1024,512):
                raise ValueError('paper input dimensions must be 1024 × 512')
            return np.asarray(im.convert('L'))
    if task=='drawing':
        if paths['coordinate_units'] != 'pixel':
            raise ValueError('drawing trajectories must use pixel units')
        result = drawing_score(raster(row['target']) < 128, paths['paths'], width)
    else:
        if paths['coordinate_units'] != 'mm':
            raise ValueError('editing trajectories must use millimeter units')
        images = row['images']
        result = editing_score(raster(images['parent']) < 180, raster(images['mask']) >= 128,
                               raster(images['target']) < 180, paths, width)
    saved = [json.loads(x) for x in checked(data,manifest,f'{task}-results.jsonl').splitlines()]
    saved = next(r for r in saved if (r['id'],r['method'],r['width_mm'])==(identifier,method,width))
    differences, failures = {}, []
    for key, value in result['metrics'].items():
        expected = saved['metrics'][key]
        if value is None or expected is None:
            if value is not expected:
                failures.append(key)
            continue
        delta = abs(value-expected)
        differences[key] = delta
        tolerance = .01 if key.endswith('mm2') else 1e-6
        if delta > tolerance:
            failures.append(key)
    result.update(id=identifier,method=method,width_mm=width,task=task,
                  saved_metric_absolute_differences=differences,matches_saved=not failures,
                  mismatched_metrics=failures,
                  comparison_tolerances={'area_mm2':.01,'other_metrics':1e-6},
                  note='Numerical quadrature/polygon approximation; not continuous-area certification.')
    out.mkdir(parents=True,exist_ok=False)
    (out/'rescore.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    if failures:
        raise ValueError('rescored metrics differ: '+', '.join(failures))
    print(f'Verified {task}/{identifier}/{method}/{width:g}mm: {out}')
