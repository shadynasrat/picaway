"""Saved research evaluators and baseline adapters."""
