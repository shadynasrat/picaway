"""ROS-free adapter for the historical PICaSo 1.0 pixel traversal baseline.

This is intentionally isolated from the production package. It preserves the
legacy Zhang-Suen, recursive seam traversal, fragment merge, and endpoint
clustering stages while exposing only a binary-mask-to-polyline interface for
the common benchmark.
"""

from __future__ import annotations

import math
from typing import Sequence

import numpy as np


Point = list[int]
Stroke = list[Point]


class LegacyV1Adapter:
    """Historical recursive skeleton/pixel traversal with no ROS dependency."""

    HORIZONTAL = 0
    VERTICAL = 0

    def __init__(
        self,
        *,
        skeleton_chunk_size: int = 0,
        skeleton_max_iterations: int = 999,
        distance_threshold: int = 10,
        max_points_per_line: int = 2000,
    ) -> None:
        self.skeleton_chunk_size = skeleton_chunk_size
        self.skeleton_max_iterations = skeleton_max_iterations
        self.distance_threshold = distance_threshold
        self.max_points_per_line = max_points_per_line

    @staticmethod
    def thinning_zhang_suen(image: np.ndarray) -> np.ndarray:
        image = np.asarray(image, dtype=np.uint8).copy()
        previous = np.zeros(image.shape, dtype=np.uint8)
        while True:
            image = LegacyV1Adapter._thinning_iteration(image, 0)
            image = LegacyV1Adapter._thinning_iteration(image, 1)
            if np.array_equal(previous, image):
                return image
            previous = image

    @staticmethod
    def _thinning_iteration(image: np.ndarray, iteration: int) -> np.ndarray:
        marker = np.zeros(image.shape, dtype=np.uint8)
        if image.shape[0] < 3 or image.shape[1] < 3:
            return image.copy()
        p2, p3, p4 = image[:-2, 1:-1], image[:-2, 2:], image[1:-1, 2:]
        p5, p6, p7 = image[2:, 2:], image[2:, 1:-1], image[2:, :-2]
        p8, p9 = image[1:-1, :-2], image[:-2, :-2]
        transitions = sum(
            ((first == 0) & (second != 0)).astype(np.uint8)
            for first, second in ((p2, p3), (p3, p4), (p4, p5), (p5, p6), (p6, p7), (p7, p8), (p8, p9), (p9, p2))
        )
        neighbors = sum(neighbor.astype(np.uint16) for neighbor in (p2, p3, p4, p5, p6, p7, p8, p9))
        m1 = p2 * p4 * (p6 if iteration == 0 else p8)
        m2 = (p4 if iteration == 0 else p2) * p6 * p8
        delete = (transitions == 1) & (neighbors >= 2) & (neighbors <= 6) & (m1 == 0) & (m2 == 0)
        marker[1:-1, 1:-1] = delete.astype(np.uint8)
        return np.bitwise_and(image, np.bitwise_not(marker))

    @staticmethod
    def _not_empty(image: np.ndarray) -> bool:
        return bool(np.sum(image) > 0)

    def _merge_impl(
        self,
        target: list[Stroke],
        incoming: list[Stroke],
        incoming_index: int,
        seam: int,
        vertical_axis: bool,
        mode: int,
    ) -> bool:
        target_left = (mode >> 1 & 1) > 0
        incoming_left = (mode >> 0 & 1) > 0
        match_index = -1
        match_distance = 4
        incoming_point = incoming[incoming_index][0 if incoming_left else -1]
        if abs(incoming_point[int(vertical_axis)] - seam) > 0:
            return False
        for index, line in enumerate(target):
            point = line[0 if target_left else -1]
            if abs(point[int(vertical_axis)] - seam) > 1:
                continue
            distance = abs(point[int(not vertical_axis)] - incoming_point[int(not vertical_axis)])
            if distance < match_distance:
                match_index, match_distance = index, distance
        if match_index == -1:
            return False
        if target_left and incoming_left:
            target[match_index] = list(reversed(incoming[incoming_index])) + target[match_index]
        elif not target_left and incoming_left:
            target[match_index] += incoming[incoming_index]
        elif target_left and not incoming_left:
            target[match_index] = incoming[incoming_index] + target[match_index]
        else:
            target[match_index] += list(reversed(incoming[incoming_index]))
        incoming.pop(incoming_index)
        return True

    def _merge_fragments(self, target: list[Stroke], incoming: list[Stroke], seam: int, direction: int) -> None:
        for index in range(len(incoming) - 1, -1, -1):
            if direction == self.HORIZONTAL:
                modes = (1, 3, 0, 2)
                axis = False
            else:
                modes = (1, 3, 0, 2)
                axis = True
            if any(self._merge_impl(target, incoming, index, seam, axis, mode) for mode in modes):
                continue
        target += incoming

    def _chunk_to_fragments(self, image: np.ndarray, x: int, y: int, width: int, height: int) -> list[Stroke]:
        fragments: list[Stroke] = []
        on_stroke = False
        last_i = last_j = -1
        for edge_index in range(height + height + width + width - 4):
            if edge_index < width:
                i, j = y, x + edge_index
            elif edge_index < width + height - 1:
                i, j = y + edge_index - width + 1, x + width - 1
            elif edge_index < width + height + width - 2:
                i, j = y + height - 1, x + width - (edge_index - width - height + 3)
            else:
                i, j = y + height - (edge_index - width - height - width + 4), x
            if image[i, j]:
                if not on_stroke:
                    on_stroke = True
                    fragments.append([[j, i], [x + width // 2, y + height // 2]])
            elif on_stroke:
                fragments[-1][0][0] = (fragments[-1][0][0] + last_j) // 2
                fragments[-1][0][1] = (fragments[-1][0][1] + last_i) // 2
                on_stroke = False
            last_i, last_j = i, j
        if len(fragments) == 2:
            line = [fragments[0][0], fragments[1][0]]
            fragments = [line]
        elif len(fragments) > 2:
            max_sum = 0
            match_i = match_j = -1
            for i in range(y + 1, y + height - 1):
                for j in range(x + 1, x + width - 1):
                    pixel_sum = int(image[i - 1 : i + 2, j - 1 : j + 2].sum())
                    distance = abs(j - (x + width // 2)) + abs(i - (y + height // 2))
                    best_distance = abs(match_j - (x + width // 2)) + abs(match_i - (y + height // 2))
                    if pixel_sum > max_sum or (pixel_sum == max_sum and distance < best_distance):
                        match_i, match_j, max_sum = i, j, pixel_sum
            if match_i != -1:
                for fragment in fragments:
                    fragment[1] = [match_j, match_i]
        return fragments

    def _trace_skeleton(self, image: np.ndarray, x: int, y: int, width: int, height: int, max_iterations: int) -> list[Stroke]:
        if max_iterations == 0:
            return []
        if width <= self.skeleton_chunk_size and height <= self.skeleton_chunk_size:
            return self._chunk_to_fragments(image, x, y, width, height)
        minimum_sum = image.shape[0] + image.shape[1]
        horizontal_seam = vertical_seam = -1
        if height > self.skeleton_chunk_size:
            for i in range(y + 3, y + height - 3):
                if image[i, x] or image[i - 1, x] or image[i, x + width - 1] or image[i - 1, x + width - 1]:
                    continue
                seam_sum = int(np.sum(image[i - 1 : i + 1, x : x + width], dtype=np.uint8))
                if seam_sum < minimum_sum or (seam_sum == minimum_sum and abs(i - (y + height // 2)) < abs(horizontal_seam - (y + height // 2))):
                    minimum_sum, horizontal_seam = seam_sum, i
        if width > self.skeleton_chunk_size:
            for j in range(x + 3, x + width - 2):
                if image[y, j] or image[y + height - 1, j] or image[y, j - 1] or image[y + height - 1, j - 1]:
                    continue
                seam_sum = int(np.sum(image[y : y + height, j - 1 : j + 1], dtype=np.uint8))
                if seam_sum < minimum_sum or (seam_sum == minimum_sum and abs(j - (x + width // 2)) < abs(vertical_seam - (x + width // 2))):
                    minimum_sum, horizontal_seam, vertical_seam = seam_sum, -1, j
        fragments: list[Stroke] = []
        if height > self.skeleton_chunk_size and horizontal_seam != -1:
            left = (x, y, width, horizontal_seam - y)
            right = (x, horizontal_seam, width, y + height - horizontal_seam)
            if self._not_empty(image):
                fragments += self._trace_skeleton(image, *left, max_iterations - 1)
                self._merge_fragments(fragments, self._trace_skeleton(image, *right, max_iterations - 1), horizontal_seam, self.VERTICAL)
        elif width > self.skeleton_chunk_size and vertical_seam != -1:
            left = (x, y, vertical_seam - x, height)
            right = (vertical_seam, y, x + width - vertical_seam, height)
            if self._not_empty(image):
                fragments += self._trace_skeleton(image, *left, max_iterations - 1)
                self._merge_fragments(fragments, self._trace_skeleton(image, *right, max_iterations - 1), vertical_seam, self.HORIZONTAL)
        if horizontal_seam == -1 and vertical_seam == -1:
            fragments += self._chunk_to_fragments(image, x, y, width, height)
        return fragments

    @staticmethod
    def _distance(first: Sequence[int], second: Sequence[int]) -> float:
        return math.hypot(second[0] - first[0], second[1] - first[1])

    def _connect_nearby_lines(self, lines: list[Stroke]) -> list[Stroke]:
        cleaned: list[Stroke] = []
        for line in lines:
            if len(line) > self.max_points_per_line or not cleaned:
                cleaned.append(line)
                continue
            connected = False
            for target in cleaned:
                if self._distance(line[0], target[-1]) <= self.distance_threshold:
                    target.extend(line)
                    connected = True
                    break
                if self._distance(line[-1], target[0]) <= self.distance_threshold:
                    target[:0] = line
                    connected = True
                    break
            if not connected:
                cleaned.append(line)
        return cleaned

    def plan(self, binary_mask: np.ndarray) -> tuple[list[Stroke], np.ndarray]:
        mask = np.asarray(binary_mask, dtype=np.uint8)
        skeleton = self.thinning_zhang_suen((mask > 0).astype(np.uint8))
        fragments = self._trace_skeleton(
            skeleton,
            0,
            0,
            skeleton.shape[1],
            skeleton.shape[0],
            self.skeleton_max_iterations,
        )
        return self._connect_nearby_lines(fragments), skeleton

