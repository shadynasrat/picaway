"""Original five baseline functions extracted without behavioral changes."""
from typing import Sequence
import cv2
import numpy as np
from planning_core.Modules.Canvas.drawing_contract import DrawingContract
from planning_core.Modules.Canvas.fill_planner import Stroke, plan_fill_region
from planning_core.Modules.Canvas.centerline_extractor import extract_centerline_graph
from .legacy_v1_adapter import LegacyV1Adapter

def _as_stroke(points: Sequence[Sequence[float]]) -> Stroke:
    return tuple((float(point[0]), float(point[1])) for point in points)

def _legacy(mask: np.ndarray, contract: DrawingContract) -> list[Stroke]:
    del contract
    paths, _ = LegacyV1Adapter().plan(mask)
    return tuple(_as_stroke(path) for path in paths)

def _centerline(mask: np.ndarray, contract: DrawingContract) -> list[Stroke]:
    result = extract_centerline_graph(mask, contract)
    return tuple(
        _as_stroke(contract.mm_to_pixel(np.asarray(edge.points_mm, dtype=float)))
        for edge in sorted(result.graph.edges, key=lambda item: item.edge_id)
    )

def _contours(mask: np.ndarray, contract: DrawingContract) -> list[Stroke]:
    del contract
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    paths: list[Stroke] = []
    for contour in sorted(contours, key=lambda value: (int(value[:, 0, 1].min()), int(value[:, 0, 0].min()), len(value))):
        simplified = cv2.approxPolyDP(contour, epsilon=0.5, closed=True).reshape(-1, 2)
        if len(simplified) >= 2:
            points = [(float(x), float(y)) for x, y in simplified]
            if points[0] != points[-1]:
                points.append(points[0])
            paths.append(tuple(points))
    return tuple(paths)

def _coverage(mask: np.ndarray, contract: DrawingContract) -> list[Stroke]:
    plan = plan_fill_region(
        mask,
        contract,
        spacing_mm=contract.marker_width_mm * 0.85,
        margin_mm=0.0,
        scan_angle_degrees=0,
    )
    return tuple(plan.strokes)

def _naive_hybrid(mask: np.ndarray, contract: DrawingContract) -> list[Stroke]:
    return tuple(_centerline(mask, contract)) + tuple(_coverage(mask, contract))

PLANNERS = {"legacy_picaso": _legacy, "centerline_tracing": _centerline, "contour_tracing": _contours, "coverage_planning": _coverage, "naive_centerline_coverage": _naive_hybrid}
