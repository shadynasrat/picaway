"""Download selected immutable HF bundles, verify, and extract without overwrite."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile
import tempfile


def extract_checked(archive, destination, expected):
    with Path(archive).open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    if digest != expected['sha256']:
        raise ValueError('archive checksum mismatch')
    destination = Path(destination).resolve()
    count = size = 0
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar:
            target = (destination / member.name).resolve()
            if not target.is_relative_to(destination) or not member.isfile():
                raise ValueError('unsafe archive member: ' + member.name)
            if target.exists():
                raise ValueError('duplicate archive member: ' + member.name)
            count += 1
            size += member.size
            if count > expected['files'] or size > expected['unpacked_bytes']:
                raise ValueError('archive exceeds manifest size')
            target.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(member) as src, target.open('xb') as dst:
                shutil.copyfileobj(src, dst)
    if count != expected['files'] or size != expected['unpacked_bytes']:
        raise ValueError('archive count/size does not match manifest')


def download(repo, revision, bundles, out):
    from huggingface_hub import hf_hub_download
    if not re.fullmatch(r'[a-fA-F0-9]{40}', revision):
        raise ValueError('--revision must be a full commit SHA for reproducibility')
    out = Path(out)
    if out.exists():
        raise ValueError('output directory already exists; choose a new directory')
    index_path = hf_hub_download(repo_id=repo, repo_type='dataset', revision=revision, filename='bundles.json')
    index = json.loads(Path(index_path).read_text())
    names = list(index['bundles']) if 'all' in bundles else list(dict.fromkeys(['results', *bundles]))
    unknown = set(names) - set(index['bundles'])
    if unknown:
        raise ValueError('unknown bundles: ' + ', '.join(sorted(unknown)))
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.footprint-download-', dir=out.parent) as tmp:
        stage = Path(tmp)
        for name in names:
            entry = index['bundles'][name]
            archive = hf_hub_download(repo_id=repo, repo_type='dataset', revision=revision, filename=entry['file'])
            extract_checked(archive, stage, entry)
        (stage/'download-revision.json').write_text(json.dumps({'repo':repo,'revision':revision,'bundles':names},indent=2)+'\n')
        # All archives have passed integrity checks before becoming the requested output.
        if out.exists():
            raise ValueError('output directory appeared during download')
        stage.rename(out)
    print(out)
