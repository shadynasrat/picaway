"""Independent coverage checks and geometric non-regression for hybrid V2."""

import unittest

import networkx as nx
import numpy as np

from planning_core.Modules.Canvas import continuous_coverage as v1
from planning_core.Modules.Canvas.drawing_contract import DrawingContract
from planning_core.Modules.Canvas.hybrid_coverage import (
    GUARDED_METRICS, HybridPolicy, _bounded_route, _curve, improve_routes,
    no_regression, plan_hybrid_coverage, route_metrics,
)
from test_continuous_coverage import independent_render


class HybridCoverageTest(unittest.TestCase):
    def setUp(self):
        self.contract = DrawingContract("test", 80, 60, 80, 60, 5)
        self.policy = HybridPolicy(audit_scale=1, allow_detail_spill=False)

    def test_redundant_excursion_removed_without_losing_coverage(self):
        paths = [np.array([[10., 30], [35, 30], [20, 30], [65, 30]])]
        target = independent_render(paths, self.contract)
        result, details = improve_routes(paths, target, self.contract, self.policy)
        np.testing.assert_array_equal(independent_render(result, self.contract), target)
        self.assertEqual(len(result[0]), 2)
        self.assertGreater(details["shortcuts"], 0)
        self.assertEqual(len(paths[0]), 4)  # Inputs remain unchanged.
        self.assertTrue(no_regression(route_metrics(result, self.contract), route_metrics(paths, self.contract)))

    def test_branches_holes_and_true_dots_keep_coverage(self):
        for seeds, touches in (
            ([[[10, 20], [65, 20]], [[35, 20], [35, 50]]], 1),
            ([[[15, 15], [55, 15], [55, 40], [15, 40], [15, 15]], [[55, 25], [70, 25]]], 1),
            ([[[12, 12]], [[60, 45]], [[10, 35], [35, 35]]], 3),
        ):
            target = independent_render([np.asarray(p) for p in seeds], self.contract)
            result = plan_hybrid_coverage(target, contract=self.contract, policy=self.policy)
            self.assertEqual(result.status, "diagnostic_coarse_only")
            self.assertEqual(len(result.paths), touches)
            np.testing.assert_array_equal(independent_render(result.paths, self.contract), target)
            self.assertTrue(no_regression(result.metrics, result.metrics["reference_metrics"]))
            for p in result.paths:
                self.assertTrue(len(p) == 1 or np.all(np.linalg.norm(np.diff(p, axis=0), axis=1) > 1e-10))

    def test_last_covering_pass_cannot_be_shortcut(self):
        paths = [np.array([[10., 20], [35, 20], [35, 45], [35, 20], [65, 20]])]
        target = independent_render(paths, self.contract)
        result, _ = improve_routes(paths, target, self.contract)
        np.testing.assert_array_equal(independent_render(result, self.contract), target)
        self.assertTrue(any(np.max(p[:, 1]) >= 45 for p in result))

    def test_each_metric_is_guarded(self):
        baseline = route_metrics([np.array([[10., 20], [35, 20], [35, 45]])], self.contract)
        for name in GUARDED_METRICS:
            worse = dict(baseline)
            worse[name] += 1
            self.assertFalse(no_regression(worse, baseline), name)

    def test_finer_coverage_cannot_be_traded_for_shorter_routes(self):
        seeds = [np.array([[10., 20], [65, 20]]), np.array([[35., 20], [35, 50]])]
        target = independent_render(seeds, self.contract)
        reference = v1.plan_continuous_coverage(target, contract=self.contract).paths
        result = plan_hybrid_coverage(target, contract=self.contract, policy=self.policy,
                                     reference_paths=reference)
        factor, pad = 2, 12
        fine_target = np.pad(target.repeat(factor, 0).repeat(factor, 1), pad)
        h, w = fine_target.shape
        fine = DrawingContract("independent-fine", w, h, w/factor, h/factor, 5)
        def render(paths):
            return independent_render([(p+.5)*factor-.5+pad for p in paths], fine)
        before, after = render(reference), render(result.paths)
        self.assertFalse(np.any(before & fine_target & ~after))
        self.assertFalse(np.any(after & ~fine_target & ~before))

    def test_bounded_parity_route_visits_all_edges(self):
        # A comb has >64 odd vertices and exercises the scalable parity route.
        coords = np.asarray([(x, y) for x in range(70) for y in (0, 1)])
        graph = nx.Graph()
        for x in range(70):
            v1._add_edge(graph, 2*x, 2*x+1, coords, np.ones(2))
            if x:
                v1._add_edge(graph, 2*x-2, 2*x, coords, np.ones(2))
        paths, bounded = _bounded_route(graph, coords)
        self.assertEqual(bounded, 1)
        self.assertEqual(len(paths), 1)
        lookup = {tuple(p): i for i, p in enumerate(coords)}
        edges = {frozenset((lookup[tuple(a)], lookup[tuple(b)])) for a, b in zip(paths[0][:-1], paths[0][1:])}
        self.assertEqual(edges, {frozenset(e) for e in graph.edges})

    def test_refinement_distinguishes_one_and_two_mm_markers(self):
        for width in (1., 2.):
            contract = DrawingContract("coarse", 32, 24, 43.75, 32.8125, width)
            target = np.zeros(contract.canvas_shape, bool)
            target[12, 5:27] = True
            coarse = plan_hybrid_coverage(target, contract=contract, policy=self.policy)
            self.assertEqual(coarse.status, "diagnostic_coarse_only")
            strict = plan_hybrid_coverage(target, contract=contract, policy=HybridPolicy(allow_detail_spill=False))
            if width == 2.:
                self.assertEqual(strict.status, "infeasible_on_refined_grid")
                self.assertGreater(strict.audit["unreachable_pixels"], 0)
                self.assertFalse(strict.paths)
            else:
                self.assertEqual(strict.status, "complete_on_refined_grid")
                self.assertEqual(strict.audit["unreachable_pixels"], 0)
                self.assertTrue(strict.paths)
            self.assertGreaterEqual(min(strict.audit["planning_marker_width_pixels"]), 4)

    def test_refined_export_round_trip_and_anisotropic_units(self):
        # A rectangular target is exactly reachable with this subpixel disk.
        contract = DrawingContract("export", 16, 12, 16, 24, .5)
        target = np.zeros(contract.canvas_shape, bool)
        target[4:8, 4:12] = True
        policy = HybridPolicy(audit_scale=2, minimum_marker_samples=1, maximum_refinement_scale=8, allow_detail_spill=False)
        result = plan_hybrid_coverage(target, contract=contract, policy=policy)
        self.assertEqual(result.status, "complete_on_refined_grid")
        factor = result.audit["scale"]
        refined = DrawingContract("check", 16*factor, 12*factor, 16, 24, .5)
        paths = [(p+.5)*factor-.5 for p in result.paths]
        np.testing.assert_array_equal(independent_render(paths, refined), target.repeat(factor, 0).repeat(factor, 1))
        self.assertFalse(result.to_dict()["robot_ready"])

    def test_curve_fitting_preserves_endpoints_in_physical_units(self):
        t = np.linspace(0, 1, 17)
        points = np.c_[10+40*t, 20+10*t*(1-t)]
        curve = _curve(points, np.array([2., .5]))
        np.testing.assert_allclose(curve[[0, -1]], points[[0, -1]])
        self.assertLess(len(curve), len(points))

    def test_random_targets_preserve_coverage_and_all_guards(self):
        rng = np.random.default_rng(9021)
        contract = DrawingContract("random", 32, 24, 24, 30, 2)
        for _ in range(10):
            seeds = []
            for __ in range(3):
                walk = np.cumsum(rng.integers(-1, 2, size=(15, 2)), axis=0) + [16, 12]
                seeds.append(np.clip(walk, [5, 5], [26, 18]))
            target = independent_render(seeds, contract)
            result = plan_hybrid_coverage(target, contract=contract, policy=self.policy)
            self.assertEqual(result.status, "diagnostic_coarse_only")
            np.testing.assert_array_equal(independent_render(result.paths, contract), target)
            self.assertTrue(no_regression(result.metrics, result.metrics["reference_metrics"]))

    def test_empty_and_stable_turn_threshold(self):
        result = plan_hybrid_coverage(np.zeros(self.contract.canvas_shape), contract=self.contract)
        self.assertEqual(result.status, "empty")
        self.assertFalse(result.paths)
        exact_45 = np.array([[0., 0], [10, 0], [20, 10]])
        self.assertEqual(route_metrics([exact_45], self.contract)["stable_turns_over_45_degrees"], 0)

    def test_resolution_cap_and_invalid_inputs(self):
        small = DrawingContract("tiny", 16, 12, 160, 120, 1)
        result = plan_hybrid_coverage(np.ones(small.canvas_shape), contract=small)
        self.assertEqual(result.status, "insufficient_grid_resolution")
        self.assertFalse(result.paths)
        for kwargs in ({"audit_scale": 0}, {"minimum_marker_samples": float("nan")},
                       {"minimum_segment_mm": 0}, {"shortcut_spans": (1,)}, {"maximum_refinement_scale": 1}):
            with self.assertRaises(ValueError):
                HybridPolicy(**kwargs)
        with self.assertRaises(ValueError):
            plan_hybrid_coverage(np.zeros((2, 2)), contract=self.contract)
        target = independent_render([np.array([[10., 20], [60, 20]])], self.contract)
        with self.assertRaises(ValueError):
            plan_hybrid_coverage(target, contract=self.contract, policy=self.policy,
                                 reference_paths=[np.array([[10., 20], [15, 20]])])
        for invalid in (np.empty((0, 2)), np.array([[np.nan, 20]]), np.array([1, 2])):
            with self.assertRaises(ValueError):
                plan_hybrid_coverage(target, contract=self.contract, policy=self.policy,
                                     reference_paths=[invalid])


if __name__ == "__main__":
    unittest.main()
