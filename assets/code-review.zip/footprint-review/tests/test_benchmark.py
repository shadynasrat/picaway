import ast
import hashlib
import json
from pathlib import Path
import unittest
import numpy as np
from footprint import DrawingContract
from footprint.cli import plan

ROOT = Path(__file__).resolve().parents[1]

class BenchmarkTest(unittest.TestCase):
    def test_baseline_functions_unchanged(self):
        manifest=json.loads((ROOT/'docs/source-manifest.json').read_text())
        for item in manifest['extractions']:
            text=(ROOT/item['packaged']).read_text()
            functions={n.name:ast.get_source_segment(text,n) for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
            for name,expected in item['function_sha256'].items():
                self.assertEqual(hashlib.sha256(functions[name].encode()).hexdigest(),expected)

    def test_all_baselines_handle_empty_and_nonempty(self):
        from footprint.benchmark.baselines import PLANNERS
        contract=DrawingContract('baseline-test',40,30,40,30,3)
        empty=np.zeros((30,40),bool)
        target=empty.copy();target[10:14,8:32]=True
        for method in PLANNERS:
            with self.subTest(method=method):
                self.assertEqual(len(plan(empty,contract,method)[0]),0)
                paths,_=plan(target,contract,method)
                self.assertTrue(len(paths))
                for path in paths:
                    self.assertEqual(path.shape[1],2)
                    self.assertTrue(np.isfinite(path).all())

    def test_scanline_capsule_area(self):
        from footprint.benchmark.drawing_evaluator import evaluate
        for paths,length in [([[[6,6]]],0),([[[3,6],[9,6]]],6),([[[3,6],[9,6],[3,6]]],6)]:
            metrics=evaluate(np.ones((14,14),bool),paths,2,factor=64)
            self.assertAlmostEqual(metrics['painted_area_mm2'],2*length+np.pi,delta=.02)

    def test_editing_footprint_keeps_off_canvas_area(self):
        from footprint.benchmark.editing_evaluator import footprint
        from shapely.geometry import box
        dot=footprint([[[-3,-3]]],2,128)
        self.assertAlmostEqual(dot.area,np.pi,delta=.001)
        self.assertEqual(dot.intersection(box(0,0,10,10)).area,0)
