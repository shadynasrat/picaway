"""Coverage, white-space, connectivity and routing regression tests."""

import unittest

import numpy as np

from planning_core.Modules.Canvas.continuous_coverage import (
    ContinuousCoveragePolicy, _Footprint, _primitives,
    path_metrics, plan_continuous_coverage, render_swept_paths,
)
from planning_core.Modules.Canvas.drawing_contract import DrawingContract


def independent_render(paths, contract):
    """Whole-canvas analytic reference, without the planner's window/stencils."""
    y, x = np.indices(contract.canvas_shape)
    samples = contract.pixel_to_mm(np.stack((x, y), axis=-1))
    result = np.zeros(contract.canvas_shape, bool)
    for path in paths:
        mm = contract.pixel_to_mm(path)
        edges = list(zip(mm[:-1], mm[1:])) if len(mm) > 1 else [(mm[0], mm[0])]
        for a, b in edges:
            delta = b - a
            denominator = float(delta @ delta)
            t = np.clip(np.sum((samples - a) * delta, axis=-1) / denominator, 0, 1) if denominator else np.zeros(contract.canvas_shape)
            distance = np.sum((samples - a - t[..., None] * delta) ** 2, axis=-1)
            result |= distance <= contract.marker_radius_mm ** 2 + 1e-10
    return result


class ContinuousCoverageTest(unittest.TestCase):
    def setUp(self):
        self.contract = DrawingContract("test", 80, 60, 80, 60, 5)

    def check_plan(self, seed, touches=1, contract=None, policy=None):
        contract = contract or self.contract
        target = independent_render([np.asarray(p) for p in seed], contract)
        result = plan_continuous_coverage(target, contract=contract, policy=policy)
        self.assertEqual(result.status, "complete_on_planning_grid")
        np.testing.assert_array_equal(independent_render(result.paths, contract), target)
        self.assertEqual(len(result.paths), touches)
        for path in result.paths:
            self.assertTrue(len(path) == 1 or np.all(np.linalg.norm(np.diff(path, axis=0), axis=1) > 1e-10))
        return result

    def test_line_has_no_return_or_dots(self):
        result = self.check_plan([[[10, 30], [65, 30]]])
        self.assertAlmostEqual(result.metrics["pen_down_mm"], 55)
        self.assertEqual(result.metrics["waypoints"], 2)

    def test_branch_is_one_touch_and_retrace_is_measured(self):
        result = self.check_plan([[[10, 20], [65, 20]], [[35, 20], [35, 50]]])
        self.assertGreater(result.metrics["collinear_retrace_mm"], 0)
        self.assertEqual(result.metrics["zero_length_routes"], 0)

    def test_loop_with_branch_and_white_hole(self):
        result = self.check_plan([[[15, 15], [55, 15], [55, 40], [15, 40], [15, 15]], [[55, 25], [70, 25]]])
        self.assertLess(result.metrics["pen_down_mm"], 175)

    def test_real_dots_and_disconnected_regions_stay_separate(self):
        result = self.check_plan([[[12, 12]], [[60, 45]], [[10, 35], [35, 35]]], touches=3)
        self.assertEqual(result.metrics["zero_length_routes"], 2)

    def test_anisotropic_pixels_use_physical_marker(self):
        contract = DrawingContract("anisotropic", 80, 60, 120, 30, 4)
        self.check_plan([[[10, 15], [60, 15]], [[40, 15], [40, 45]]], contract=contract)

    def test_filled_region_stitches_and_remains_complete(self):
        seed = [[[x, 15], [x, 42]] for x in range(15, 60)]
        result = self.check_plan(seed)
        self.assertGreater(result.metrics["contour_stitches"], 0)
        self.assertEqual(result.metrics["zero_length_routes"], 0)

    def test_impossible_detail_returns_no_paths(self):
        target = np.zeros(self.contract.canvas_shape, bool)
        target[30, 10:60] = True
        result = plan_continuous_coverage(target, contract=self.contract)
        self.assertEqual(result.status, "infeasible_on_planning_grid")
        self.assertFalse(result.paths)
        self.assertEqual(result.metrics["unreachable_pixels"], 50)

    def test_empty(self):
        result = plan_continuous_coverage(np.zeros(self.contract.canvas_shape), contract=self.contract)
        self.assertEqual(result.status, "empty")
        self.assertFalse(result.paths)

    def test_smoothing_never_introduces_tiny_segments(self):
        contract = DrawingContract("small", 80, 60, 40, 30, 2)
        result = self.check_plan([[[10, 20], [65, 20]], [[35, 20], [35, 50]]], contract=contract)
        self.assertGreaterEqual(result.metrics["minimum_segment_mm"], 0.15 - 1e-9)

    def test_retrace_metric_handles_partial_overlaps(self):
        metrics = path_metrics([np.array([[10, 20], [40, 20], [25, 20]])], self.contract)
        self.assertAlmostEqual(metrics["collinear_retrace_mm"], 15)

    def test_primitive_catalogue_matches_brute_force(self):
        rng = np.random.default_rng(402)
        for sx, sy, width in ((1, 1, 0.8), (1, 1, 2), (0.7, 1.4, 2.1)):
            contract = DrawingContract("small", 9, 8, 9 * sx, 8 * sy, width)
            target = rng.random(contract.canvas_shape) > 0.12
            footprint = _Footprint(contract)
            primitives, maximum = _primitives(target, footprint)
            expected = np.zeros_like(target)
            # Explicitly padded reference checks all exterior pixel samples.
            pad = 5
            padded_contract = DrawingContract("padded", 19, 18, 19 * sx, 18 * sy, width)
            padded_target = np.pad(target, pad)
            for dx, dy, legal, _ in primitives:
                for y in range(8):
                    for x in range(9):
                        path = np.array([[x, y], [x + dx, y + dy]])
                        sweep = independent_render([path + pad], padded_contract)
                        possible = 0 <= x + dx < 9 and 0 <= y + dy < 8 and not np.any(sweep & ~padded_target)
                        self.assertEqual(bool(legal[y, x]), possible)
                        if possible:
                            expected |= sweep[pad:-pad, pad:-pad]
            np.testing.assert_array_equal(maximum, expected)

    def test_deterministic_and_no_stitch_fallback(self):
        seed = [[[15, 15], [55, 15], [55, 40], [15, 40], [15, 15]], [[55, 25], [70, 25]]]
        policy = ContinuousCoveragePolicy(stitch_contours=False, smooth=False)
        a = self.check_plan(seed, policy=policy)
        b = self.check_plan(seed, policy=policy)
        self.assertEqual([p.tolist() for p in a.paths], [p.tolist() for p in b.paths])

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            plan_continuous_coverage(np.zeros((2, 2)), contract=self.contract)
        for kwargs in ({"stepover_fraction": 0}, {"corner_fraction": float("nan")}, {"minimum_curve_segment_mm": -1}):
            with self.assertRaises(ValueError):
                ContinuousCoveragePolicy(**kwargs)

    def test_seeded_random_targets_keep_coverage_and_white_gaps(self):
        rng = np.random.default_rng(291)
        contract = DrawingContract("random", 32, 24, 32, 24, 3)
        for _ in range(12):
            seed = []
            for __ in range(4):
                start = rng.integers([5, 5], [26, 18])
                walk = [start.copy()]
                for ___ in range(8):
                    step = rng.integers(-1, 2, size=2)
                    start = np.clip(start + step, [4, 4], [27, 19])
                    walk.append(start.copy())
                seed.append(np.asarray(walk))
            target = independent_render(seed, contract)
            result = plan_continuous_coverage(target, contract=contract)
            self.assertEqual(result.status, "complete_on_planning_grid")
            np.testing.assert_array_equal(independent_render(result.paths, contract), target)
            self.assertEqual(len(result.paths), result.metrics["used_safe_centre_components"])


if __name__ == "__main__":
    unittest.main()
