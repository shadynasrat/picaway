import hashlib
import io
from pathlib import Path
import tarfile
import tempfile
import unittest
from footprint.download import extract_checked

class DownloadTest(unittest.TestCase):
    def archive(self, path, name='a/test.txt', kind=None):
        with tarfile.open(path,'w:gz') as tar:
            member=tarfile.TarInfo(name)
            if kind is not None:
                member.type=kind;member.linkname='/tmp/unwanted';member.size=0;tar.addfile(member)
            else:
                member.size=4;tar.addfile(member,io.BytesIO(b'test'))
        return {'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'files':1,'unpacked_bytes':0 if kind else 4}

    def test_extract_regular_file_and_reject_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);path=root/'archive.tar.gz';spec=self.archive(path);out=root/'out';out.mkdir()
            extract_checked(path,out,spec)
            self.assertEqual((out/'a/test.txt').read_bytes(),b'test')
            with self.assertRaises(ValueError):extract_checked(path,out,spec)

    def test_reject_traversal_links_and_wrong_hash(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);out=root/'out';out.mkdir();path=root/'archive.tar.gz'
            for name,kind in [('../outside.txt',None),('/absolute.txt',None),('link',tarfile.SYMTYPE),('hardlink',tarfile.LNKTYPE)]:
                spec=self.archive(path,name,kind)
                with self.assertRaises(ValueError):extract_checked(path,out,spec)
            spec=self.archive(path);spec['sha256']='0'*64
            with self.assertRaises(ValueError):extract_checked(path,out,spec)
            self.assertFalse((root/'outside.txt').exists())
