"""Physical-footprint and routing regressions for the coverage-first policy."""
import unittest
from collections import Counter
import numpy as np
from planning_core.Modules.Canvas.drawing_contract import DrawingContract
from planning_core.Modules.Canvas.coverage_routing import coverage_envelope, order_routes, smooth_traversal
from planning_core.Modules.Canvas.hybrid_coverage import HybridPolicy, plan_hybrid_coverage, route_metrics
from test_continuous_coverage import independent_render


class CoverageRoutingTest(unittest.TestCase):
    def test_already_connected_corner_repairs_do_not_add_connectors(self):
        contract = DrawingContract("corners", 40, 40, 40, 40, 5)
        target = np.zeros((40, 40), bool); target[8:32, 8:32] = True
        _, details = coverage_envelope(target, contract)
        self.assertGreater(details["repair_stamps"], 0)
        self.assertEqual(details["detail_connections"], 0)

    def test_thin_details_covered_with_local_spill_and_white_gap_preserved(self):
        contract = DrawingContract("thin", 48, 32, 48, 32, 3)
        target = np.zeros((32, 48), bool)
        target[8:25, 8] = True
        target[8:25, 36] = True
        result = plan_hybrid_coverage(target, contract=contract,
                                     policy=HybridPolicy(audit_scale=1, allow_detail_spill=True))
        ink = independent_render(result.paths, contract)
        self.assertTrue(np.all(ink[target]))
        self.assertGreater(np.count_nonzero(ink & ~target), 0)
        self.assertFalse(ink[:, 15:30].any())
        self.assertEqual(len(result.paths), 2)
        self.assertEqual(result.metrics["unwanted_pixels"], np.count_nonzero(ink & ~target))

    def test_edge_contact_counted_on_padded_canvas(self):
        contract = DrawingContract("edge", 12, 12, 12, 12, 3)
        target = np.zeros((12, 12), bool); target[0, 0] = True
        result = plan_hybrid_coverage(target, contract=contract,
                                     policy=HybridPolicy(audit_scale=1, allow_detail_spill=True))
        self.assertEqual(result.metrics["unwanted_pixels"], 8)
        self.assertEqual(result.metrics["coverage_fraction"], 1)

    def test_refined_mode_covers_all_refined_target_samples(self):
        contract = DrawingContract("refined", 20, 16, 40, 16, 3)
        target = np.zeros((16, 20), bool)
        target[3:13, 4] = True; target[9, 4:16] = True
        result = plan_hybrid_coverage(target, contract=contract,
                                     policy=HybridPolicy(allow_detail_spill=True))
        factor = result.audit["scale"]
        refined = target.repeat(factor, 0).repeat(factor, 1)
        h, w = refined.shape
        calibration = DrawingContract("independent", w, h, 40, 16, 3)
        paths = [(p+.5)*factor-.5 for p in result.paths]
        painted = independent_render(paths, calibration)
        self.assertTrue(np.all(painted[refined]))
        self.assertGreater(factor, 1)

    def test_connected_diagonal_detail_does_not_fragment_into_dots(self):
        contract = DrawingContract("bent-detail", 40, 32, 40, 32, 3)
        target = np.zeros((32, 40), bool)
        target[np.arange(6, 21), np.arange(6, 21)] = True
        target[20, 20:33] = True
        result = plan_hybrid_coverage(target, contract=contract)
        self.assertEqual(len(result.paths), 1)
        self.assertEqual(result.metrics["zero_length_routes"], 0)
        self.assertEqual(result.metrics["coverage_fraction"], 1)

    def test_loop_entry_changes_without_changing_ink(self):
        contract = DrawingContract("order", 80, 80, 160, 80, 2)
        paths = [np.array([[5., 20], [19, 20]]),
                 np.array([[60., 60], [20, 60], [20, 20], [60, 20], [60, 60]]),
                 np.array([[70., 60], [75, 60]])]
        ordered = order_routes(paths, contract)
        self.assertLess(route_metrics(ordered, contract)["pen_up_mm"], route_metrics(paths, contract)["pen_up_mm"])
        np.testing.assert_array_equal(independent_render(ordered, contract), independent_render(paths, contract))
        self.assertEqual(len(ordered), len(paths))
        np.testing.assert_array_equal(paths[1][0], [60, 60])

    def test_turn_order_preserves_edges_multiplicity_and_endpoints(self):
        path = np.array([[0., 0], [1, 0], [1, 1], [1, 0], [2, 0], [1, 0], [1, -1]])
        result = smooth_traversal(path, np.array([2., 1.]))
        def edges(p):
            return Counter(tuple(sorted((tuple(a), tuple(b)))) for a, b in zip(p[:-1], p[1:]))
        self.assertEqual(edges(result), edges(path))
        np.testing.assert_array_equal(result[[0, -1]], path[[0, -1]])


if __name__ == "__main__":
    unittest.main()
