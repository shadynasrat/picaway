import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import numpy as np
from PIL import Image
from footprint.cli import render
from footprint import DrawingContract

ROOT = Path(__file__).resolve().parents[1]


class ReleaseTest(unittest.TestCase):
    def test_frozen_sources(self):
        manifest = json.loads((ROOT / 'docs/source-manifest.json').read_text())
        for item in manifest['modules']:
            self.assertEqual(hashlib.sha256((ROOT / item['packaged']).read_bytes()).hexdigest(), item['sha256'])

    def test_edit_preserves_protected_ink_and_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as folder:
            out = Path(folder) / 'edit'
            command = [sys.executable, '-m', 'footprint', 'edit', '--parent', str(ROOT / 'examples/parent.png'), '--mask', str(ROOT / 'examples/mask.png'), '--updated', str(ROOT / 'examples/updated.png'), '--width-mm', '3', '--canvas-mm', '64', '48', '--out', str(out)]
            result = subprocess.run(command, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            data = json.loads((out / 'paths.json').read_text())
            parent = np.asarray(Image.open(ROOT / 'examples/parent.png')) < 180
            mask = np.asarray(Image.open(ROOT / 'examples/mask.png')) >= 128
            contract = DrawingContract('check', 64, 48, 64, 48, 3)
            erased = render([contract.mm_to_pixel(np.asarray(p)) for p in data['erase_paths_mm']], contract)
            self.assertFalse(np.any(erased & parent & ~mask))
            self.assertTrue(data['erase_paths_mm'])
            self.assertTrue(data['draw_paths_mm'])
            before = (out / 'paths.json').read_bytes()
            repeat = subprocess.run(command, capture_output=True, text=True)
            self.assertNotEqual(repeat.returncode, 0)
            self.assertEqual(before, (out / 'paths.json').read_bytes())

    def test_draw_coordinates_match_library(self):
        from footprint import plan_footprint, FootprintPolicy
        with tempfile.TemporaryDirectory() as folder:
            out = Path(folder) / 'draw'
            command = [sys.executable, '-m', 'footprint', 'draw', str(ROOT / 'examples/drawing.png'), '--width-mm', '3', '--canvas-mm', '64', '48', '--out', str(out)]
            result = subprocess.run(command, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            data = json.loads((out / 'paths.json').read_text())
            mask = np.asarray(Image.open(ROOT / 'examples/drawing.png')) < 128
            contract = DrawingContract('check', 64, 48, 64, 48, 3)
            expected = plan_footprint(mask, contract=contract, policy=FootprintPolicy())
            self.assertEqual(data['paths_mm'], [contract.pixel_to_mm(p).tolist() for p in expected.paths])
